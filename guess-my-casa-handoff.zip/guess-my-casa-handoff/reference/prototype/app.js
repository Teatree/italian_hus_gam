/* ==========================================================================
   Guess My Casa — reference prototype behaviour
   Vanilla JS so it runs from file:// with no build. It is a REFERENCE for look,
   states and motion — the real app keeps its own React state, rules, storage,
   analytics and data loading. Do not copy the game rules from here; reuse the
   existing ones in the codebase.

   URL params:
     screen   = start|typing|invalid|mid|clues|review|last|zoom|help|win|exact|loss|zoomEnd|verdict|copied|pastday|nopuzzle
     mode     = dark|light            (default: saved choice, else dark)
     country  = it|es|pt|fr|gr|fi       (or Italy|Spain|Portugal|France|Greece)
     season   = halloween            (optional seasonal override)
     frozen=1 → countdown fixed at 21:59:58 (for screenshots)
     fx=0     → no confetti/rain/autoplay (for screenshots)
     capture=full → anchor ad rendered at the end of the page instead of fixed
   Scripting hooks: window.GMC.guess(800000), window.GMC.state()
   ========================================================================== */
(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const root = document.documentElement;
  const app = $('app');
  const Q = new URLSearchParams(location.search);
  const reduceMQ = matchMedia('(prefers-reduced-motion: reduce)');
  const reduced = () => reduceMQ.matches;
  const FX = Q.get('fx') !== '0';
  const FROZEN = Q.get('frozen') === '1';
  if (Q.get('capture') === 'full') root.classList.add('capture-full');
  if (Q.get('season')) root.setAttribute('data-season', Q.get('season'));

  /* ---------------- Data (in the real app this comes from the house config) ---------------- */
  const HOUSE = {
    number: 153,
    price: 800000,
    place: 'La Serra-Tellaro, Lerici',
    photos: ['img/photo-exterior.jpg', 'img/photo-bathroom.jpg', 'img/photo-exterior.jpg', 'img/photo-bedroom.jpg', 'img/photo-bathroom.jpg', 'img/photo-bedroom.jpg'],
    hints: ['Located in La Serra-Tellaro, Lerici', '4 rooms · 2 baths', '1 floor', '110 m² of living space', 'Private garden', '20 min to La Spezia by car'],
    hasVerdictQuestion: true,
    shareFlag: '🇮🇪',
    dayParam: '01_11_26'
  };
  const COUNTRIES = {
    it: { name: 'Italia', word: 'Casa', flag: ['#009246', '#F4F5F0', '#CE2B37'] },
    es: { name: 'España', word: 'Casa', flag: ['#AA151B', '#F1BF00', '#AA151B'] },
    pt: { name: 'Portugal', word: 'Casa', flag: ['#046A38', '#DA291C', '#FFE900'] },
    fr: { name: 'France', word: 'Maison', flag: ['#0055A4', '#F4F5F0', '#EF4135'] },
    gr: { name: 'Hellas', word: 'Spíti', flag: ['#0D5EAF', '#F4F5F0', '#0D5EAF'] },
    fi: { name: 'Suomi', word: 'Talo', flag: ['#002F6C', '#F4F5F0', '#002F6C'] }
  };
  const ALIAS = { italy: 'it', spain: 'es', portugal: 'pt', france: 'fr', greece: 'gr', finland: 'fi' };
  const cq = (Q.get('country') || 'it').toLowerCase();
  const CC = COUNTRIES[cq] ? cq : (ALIAS[cq] || 'it');
  root.setAttribute('data-country', CC);

  /* ---------------- Seeds: one per screen in the screenshots ---------------- */
  const MID = [300000, 1500000, 650000];
  const LAST = [300000, 1500000, 650000, 1000000, 690000];
  const WIN = [300000, 1500000, 650000, 780000];
  const SEEDS = {
    start: {}, typing: { input: '450000' }, invalid: { input: '45', err: 'Enter the full price, e.g. 450,000' },
    mid: { g: MID }, clues: { g: MID, clueOpen: true }, review: { g: MID, sel: 1 }, last: { g: LAST },
    zoom: { g: MID, overlay: 'zoom' }, help: { overlay: 'help' },
    win: { g: WIN }, exact: { g: [800000] }, loss: { g: LAST.concat([950000]) },
    zoomEnd: { g: WIN, overlay: 'zoom', sel: 1 }, verdict: { g: WIN, overlay: 'verdict' },
    copied: { g: WIN, verdict: 'fair', copied: true },
    pastday: { pastDay: true }, nopuzzle: { noPuzzle: true }
  };
  const screen = Q.get('screen') || 'start';
  const S = Object.assign({ g: [], input: '', err: null, sel: null, clueOpen: false, overlay: null, verdict: null, copied: false, pastDay: false, noPuzzle: false }, SEEDS[screen] || {});

  /* ---------------- Rules (REFERENCE ONLY — the app already has these) ---------------- */
  const P = HOUSE.price;
  const pct = (x) => Math.abs(x - P) / P;
  function derive(s) {
    const n = s.g.length;
    const winIdx = s.g.findIndex((x) => pct(x) <= 0.10);
    const won = winIdx >= 0;
    const exact = s.g.includes(P);
    const over = won || n >= 6;
    const revealed = over ? 6 : n + 1;
    const cur = over ? (won ? winIdx : 5) : n;
    const sel = s.sel == null ? cur : Math.min(s.sel, revealed - 1);
    return { n, winIdx, won, exact, over, revealed, cur, sel };
  }
  const arrowOf = (x) => x < P ? (pct(x) > 0.3 ? '↑↑' : '↑') : (pct(x) > 0.3 ? '↓↓' : '↓');
  const arrowWords = (x) => x < P ? (pct(x) > 0.3 ? 'far too low' : 'too low') : (pct(x) > 0.3 ? 'far too high' : 'too high');
  const money = (x) => '€' + Number(x).toLocaleString('en-US');
  const short = (x) => x >= 1e6 ? (x / 1e6).toFixed(1).replace(/\.0$/, '') + 'M' : Math.round(x / 1000) + 'k';

  /* ---------------- Build static parts ---------------- */
  const triesEl = $('tries');
  const tryBtns = [];
  for (let i = 0; i < 6; i++) {
    const li = document.createElement('li');
    li.innerHTML =
      '<button class="try" type="button" data-state="locked">' +
        '<span class="try__circle"><span class="try__num">' + (i + 1) + '</span><span class="try__arrow"></span>' +
        '<svg class="try__check" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span>' +
        '<span class="try__label">–</span>' +
      '</button>';
    const b = li.firstChild;
    b.addEventListener('click', () => { S.sel = i; render(); restartAutoplay(); revealPhoto(); });
    triesEl.appendChild(li);
    tryBtns.push(b);
  }
  const grid = $('cluesGrid');
  const tiles = HOUSE.hints.map((h, i) => {
    const t = document.createElement('div');
    t.className = 'tile';
    t.innerHTML =
      '<button class="tile__content" type="button" tabindex="-1"><span class="tile__num"><svg class="glass glass--s" width="14" height="14" viewBox="0 0 24 24" aria-hidden="true"><circle cx="9.8" cy="9.8" r="6.6" fill="currentColor" fill-opacity="0.18" stroke="currentColor" stroke-width="2.3"/><path d="M14.6 14.6l1.6 1.6" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/><path d="M16.9 16.9l4.3 4.3" stroke="currentColor" stroke-width="4.2" stroke-linecap="round"/></svg><span class="tile__label">CLUE ' + (i + 1) + '</span><span class="tile__new">NEW</span></span><span class="tile__text"></span></button>' +
      '<div class="shutter" aria-hidden="true"><span class="shutter__leaf shutter__leaf--l"></span><span class="shutter__leaf shutter__leaf--r"></span>' +
      '<span class="shutter__lock"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>Clue ' + (i + 1) + '</span></div>';
    t.querySelector('.tile__text').textContent = h;
    t.querySelector('.tile__content').title = h;
    t.querySelector('.tile__content').addEventListener('click', () => { S.sel = i; render(); restartAutoplay(); revealPhoto(); });
    grid.appendChild(t);
    return t;
  });
  const dotsEl = $('cluesDots');
  const dots = HOUSE.hints.map(() => { const d = document.createElement('span'); d.className = 'clues__dot'; dotsEl.appendChild(d); return d; });
  const zDots = HOUSE.hints.map(() => { const d = document.createElement('span'); d.className = 'zoom__dot'; $('zoomDots').appendChild(d); return d; });

  const c = COUNTRIES[CC];
  $('chipText').textContent = c.word + ' Nº ' + HOUSE.number + ' · ' + c.name;
  if (S.pastDay) {
    $('metaRight').textContent = 'Sat 31 Oct';
    $('pastday').hidden = false;
  }
  $('game').hidden = S.noPuzzle;
  $('noCasa').hidden = !S.noPuzzle;

  /* ---------------- Helpers ---------------- */
  function retrigger(el, cls, ms) {
    el.classList.remove(cls); void el.offsetWidth; el.classList.add(cls);
    clearTimeout(el['_t_' + cls]);
    el['_t_' + cls] = setTimeout(() => el.classList.remove(cls), ms || 1400);
  }
  function instantly(el, fn) { el.classList.add('no-anim'); fn(); void el.offsetWidth; requestAnimationFrame(() => el.classList.remove('no-anim')); }
  function revealPhoto() {
    const r = $('clueTag').getBoundingClientRect();
    if (r.top < 0) window.scrollTo({ top: window.scrollY + r.top - 8, behavior: reduced() ? 'auto' : 'smooth' });
  }

  /* Photo crossfade: two stacked <img>, the incoming one fades in over the outgoing one. */
  let front = $('imgA'), back = $('imgB');
  function crossfade(src, alt, ms) {
    [front, back].forEach((im) => im.style.setProperty('--fade', (reduced() ? 1 : ms) + 'ms'));
    back.src = src; back.alt = alt;
    const go = () => {
      back.classList.add('is-entering'); void back.offsetWidth;
      back.classList.add('is-front'); back.removeAttribute('aria-hidden');
      front.classList.remove('is-front', 'is-entering'); front.setAttribute('aria-hidden', 'true');
      const t = front; front = back; back = t;
    };
    (back.decode ? back.decode().catch(() => {}) : Promise.resolve()).then(go);
  }
  /* Clue swap: old text slides up/fades (140ms), new text fades in.
     A NEW clue (after a wrong guess) also replays the pill entrance + magnifier wiggle on the whole tag. */
  function setClue(el, text) {
    el.textContent = text;
    const tag = el.closest('.clue-tag');
    tag.hidden = !text;
    tag.setAttribute('aria-label', 'Clue ' + (derive(S).sel + 1) + ' of 6: ' + text);
  }
  function swapHint(el, text, isNew) {
    const tag = el.closest('.clue-tag');
    tag.classList.remove('is-new');
    if (reduced()) { setClue(el, text); return; }
    el.classList.add('is-out');
    clearTimeout(el._swap);
    el._swap = setTimeout(() => {
      setClue(el, text); el.classList.remove('is-out');
      if (isNew) { void tag.offsetWidth; tag.classList.add('is-new'); }
    }, 140);
  }

  /* ---------------- Render ---------------- */
  let prev = null;
  let unusedReady = true;
  function tryState(i, d) {
    if (i < d.n) return i === d.winIdx ? 'right' : 'wrong';
    if (!d.over) return i === d.n ? 'now' : 'locked';
    return unusedReady ? 'unused' : 'locked';
  }

  function render() {
    const d = derive(S);
    const p = prev;
    const first = !p;
    app.classList.toggle('is-over', d.over);
    $('zoom').classList.toggle('is-over', d.over);

    /* photo + hint */
    const alt = 'Listing photo ' + (d.sel + 1) + ' of 6';
    const newHint = !first && !d.over && d.revealed > p.revealed;
    if (first) {
      front.src = HOUSE.photos[d.sel]; front.alt = alt;
      setClue($('hint'), HOUSE.hints[d.sel]);
    } else if (p.sel !== d.sel) {
      crossfade(HOUSE.photos[d.sel], alt, d.over ? 700 : 400);
      swapHint($('hint'), HOUSE.hints[d.sel], newHint);
    }
    const reviewing = !d.over && d.sel !== d.cur;
    $('backChip').textContent = 'Back to try ' + (d.cur + 1) + ' →';
    $('backChip').classList.toggle('is-shown', reviewing);

    /* tries */
    tryBtns.forEach((b, i) => {
      const st = tryState(i, d);
      const old = b.dataset.state;
      b.dataset.state = st;
      const has = i < d.n;
      b.querySelector('.try__arrow').textContent = has && st === 'wrong' ? arrowOf(S.g[i]) : '';
      b.querySelector('.try__label').textContent = has ? short(S.g[i]) : st === 'now' ? 'now' : '–';
      b.disabled = !(d.over || i <= d.n);
      b.setAttribute('aria-label', has
        ? 'Try ' + (i + 1) + ': ' + money(S.g[i]) + ', ' + (st === 'right' ? 'within 10%' : arrowWords(S.g[i]))
        : st === 'now' ? 'Try ' + (i + 1) + ', current' : 'Try ' + (i + 1) + (d.over ? ', unused' : ', locked'));
      b.setAttribute('aria-current', i === d.sel ? 'true' : 'false');
      b.classList.toggle('is-ringed', i === d.sel && (d.over || d.sel !== d.cur));
      b.classList.toggle('is-last', !d.over && d.n === 5 && i === 5);
      if (!first && old !== st) {
        if (st === 'wrong' || st === 'right') retrigger(b, 'pop');
        if (st === 'now') retrigger(b, 'now-in');
      }
    });

    /* form vs result */
    const res = $('result');
    res.classList.toggle('is-win', d.won && !d.exact);
    res.classList.toggle('is-exact', d.exact);
    res.classList.toggle('is-loss', d.over && !d.won);
    $('resTitle').textContent = d.exact ? 'Right on the money!' : d.won ? 'Good job!' : 'You suck!';
    if (d.over) {
      const closest = S.g.reduce((a, b) => (pct(b) < pct(a) ? b : a));
      $('resLine').textContent = d.exact ? 'The exact price, on try ' + (d.winIdx + 1) + '. Unreal.'
        : d.won ? 'You were ' + Math.round(pct(S.g[d.winIdx]) * 100) + '% off · solved on try ' + (d.winIdx + 1)
        : 'Closest guess ' + money(closest) + ' · ' + Math.round(pct(closest) * 100) + '% off';
    }
    if (first) {
      $('guessForm').hidden = d.over; res.hidden = !d.over;
    } else if (!p.over && d.over) {
      const f = $('guessForm');
      f.classList.add('is-leaving');
      setTimeout(() => {
        f.hidden = true; f.classList.remove('is-leaving');
        res.hidden = false; retrigger(res, 'is-entering', 1200);
        countUp($('resPrice'), P, 900);
        setTimeout(() => res.scrollIntoView({ block: 'nearest', behavior: reduced() ? 'auto' : 'smooth' }), 120);
      }, reduced() ? 0 : 180);
    }

    /* input + helper */
    const field = $('field'), input = $('input'), helper = $('helper');
    const fmt = S.input ? Number(S.input).toLocaleString('en-US') : '';
    if (input.value !== fmt) input.value = fmt;
    field.classList.toggle('has-value', !!S.input && !S.err);
    field.classList.toggle('has-error', !!S.err);
    $('guessBtn').disabled = !S.input;
    helper.className = 'helper';
    if (S.err) {
      helper.classList.add('is-error');
      helper.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16.5v.5"/></svg>';
      helper.appendChild(document.createTextNode(S.err));
    } else if (d.n === 5 && !d.over) {
      helper.classList.add('is-last'); helper.textContent = 'Last try — make it count';
    } else {
      helper.textContent = 'Within 10% wins · ↑ higher · ↓ lower · ↑↑ = 30%+ off';
    }

    /* clues */
    const cl = $('clues');
    cl.classList.toggle('is-open', S.clueOpen);
    $('cluesBar').setAttribute('aria-expanded', String(S.clueOpen));
    $('cluesCount').textContent = d.revealed + ' of 6';
    let k = 0;
    const endBurst = !first && d.over && !p.over;
    tiles.forEach((t, i) => {
      const open = i < d.revealed;
      const was = t.classList.contains('is-open');
      t.classList.toggle('is-sel', open && i === d.sel);
      t.classList.toggle('is-new', !d.over && d.n > 0 && i === d.revealed - 1);
      t.querySelector('.tile__content').tabIndex = open && S.clueOpen ? 0 : -1;
      const dot = dots[i];
      if (open && !was) {
        const delay = endBurst && !reduced() ? (k++) * 450 : 0;
        const doOpen = () => {
          if (first || !S.clueOpen) instantly(t, () => t.classList.add('is-open'));
          else t.classList.add('is-open');
          dot.classList.add('is-on');
          if (!first) retrigger(dot, 'pop', 500);
        };
        delay ? setTimeout(doOpen, delay) : doOpen();
      } else if (!open && was) {
        t.classList.remove('is-open'); dot.classList.remove('is-on');
      }
    });

    /* zoom (if open) */
    if (!$('zoom').hidden) syncZoom(d, p && p.sel !== d.sel);

    prev = d;
  }

  /* Count-up for the revealed price: 0 → price, easeOutCubic. */
  function countUp(el, to, ms) {
    if (reduced()) { el.textContent = money(to); return; }
    const t0 = performance.now() + 200;
    el.textContent = money(0);
    const step = (now) => {
      const t = Math.min(1, Math.max(0, (now - t0) / ms));
      const e = 1 - Math.pow(1 - t, 3);
      el.textContent = money(Math.round((to * e) / 1000) * 1000);
      if (t < 1) requestAnimationFrame(step); else el.textContent = money(to);
    };
    requestAnimationFrame(step);
  }

  /* ---------------- Guessing ---------------- */
  const input = $('input');
  input.addEventListener('input', () => {
    const digits = input.value.replace(/\D/g, '').replace(/^0+/, '').slice(0, 9);
    S.input = digits; S.err = null;
    const f = digits ? Number(digits).toLocaleString('en-US') : '';
    if (input.value !== f) { input.value = f; input.setSelectionRange(f.length, f.length); }
    render();
  });
  $('guessForm').addEventListener('submit', (e) => { e.preventDefault(); submitGuess(); });

  function fail(msg) { S.err = msg; render(); retrigger($('field'), 'shake', 400); }
  function submitGuess() {
    if (!S.input) return;
    const v = Number(S.input);
    if (v < 10000) return fail('Enter the full price, e.g. 450,000');
    if (S.g.includes(v)) return fail('You already tried ' + money(v));
    S.g = S.g.concat([v]); S.input = ''; S.err = null; S.sel = null;
    const before = derive(Object.assign({}, S, { g: S.g.slice(0, -1) }));
    const d = derive(S);
    if (d.over && !before.over) { unusedReady = false; }
    render();
    if (d.over) onGameEnd(d); else revealPhoto();
  }
  function onGameEnd(d) {
    input.blur();
    if (d.won) confetti(d.exact); else rain();
    if (d.won) setTimeout(() => { unusedReady = true; render(); }, 2000); else unusedReady = true;
    setTimeout(startAutoplay, 4000);
  }

  /* ---------------- Clues + photo nav ---------------- */
  $('cluesBar').addEventListener('click', () => { S.clueOpen = !S.clueOpen; render(); });
  $('backChip').addEventListener('click', () => { S.sel = null; render(); });
  const step = (dir) => { const d = derive(S); S.sel = (d.sel + dir + 6) % 6; render(); restartAutoplay(); };
  $('prevBtn').addEventListener('click', () => step(-1));
  $('nextBtn').addEventListener('click', () => step(1));

  /* Carousel autoplay after the game ends: 5s per photo, 700ms crossfade, paused by zoom/sheets/hidden tab. */
  let auto = null;
  function startAutoplay() {
    if (!FX || reduced() || !derive(S).over) return;
    clearInterval(auto);
    auto = setInterval(() => {
      if (document.hidden || !$('zoom').hidden || openSheet) return;
      step(1);
    }, 5000);
  }
  function restartAutoplay() { if (auto) startAutoplay(); }

  /* ---------------- Zoom (FLIP from the on-page photo) ---------------- */
  const zoom = $('zoom'), zImg = $('zoomImg');
  let lastFocus = null;
  function syncZoom(d, changed) {
    const src = HOUSE.photos[d.sel], text = HOUSE.hints[d.sel];
    if (changed && !reduced()) {
      zImg.classList.add('is-swipe-out');
      setTimeout(() => { zImg.classList.remove('is-swipe-out'); zImg.src = src; }, 200);
      swapHint($('zoomHint'), text, false);
    } else { zImg.src = src; setClue($('zoomHint'), text); }
    zDots.forEach((z, i) => { z.classList.toggle('is-sel', i === d.sel); z.classList.toggle('is-on', i < d.revealed); });
    $('zoomCap').textContent = 'Photo ' + (d.sel + 1) + ' of 6 · ' + (d.over ? 'swipe or use the arrows' : 'more unlock with each miss');
    zoom.setAttribute('aria-label', 'Photo ' + (d.sel + 1) + ' of 6');
  }
  function flipFrom() {
    const a = $('photoFrame').getBoundingClientRect(), b = $('zoomStage').getBoundingClientRect();
    return 'translate(' + (a.left - b.left) + 'px,' + (a.top - b.top) + 'px) scale(' + a.width / b.width + ',' + a.height / b.height + ')';
  }
  function openZoom(instant) {
    lastFocus = document.activeElement;
    zoom.hidden = false;
    syncZoom(derive(S), false);
    if (instant || reduced()) { zoom.classList.add('is-shown'); }
    else {
      zImg.style.transform = flipFrom();
      requestAnimationFrame(() => requestAnimationFrame(() => {
        zImg.classList.add('is-flip'); zoom.classList.add('is-shown'); zImg.style.transform = '';
      }));
    }
    $('zoomClose').focus({ preventScroll: true });
  }
  function closeZoom() {
    if (reduced()) { zoom.classList.remove('is-shown'); zoom.hidden = true; }
    else {
      zImg.classList.add('is-flip'); zImg.style.transform = flipFrom(); zoom.classList.remove('is-shown');
      setTimeout(() => { zoom.hidden = true; zImg.classList.remove('is-flip'); zImg.style.transform = ''; }, 320);
    }
    if (lastFocus) lastFocus.focus({ preventScroll: true });
  }
  $('zoomBtn').addEventListener('click', () => openZoom());
  $('photo').addEventListener('click', (e) => { if (e.target.classList.contains('photo__img')) openZoom(); });
  $('zoomClose').addEventListener('click', closeZoom);
  $('zoomBg').addEventListener('click', closeZoom);
  $('zPrev').addEventListener('click', () => step(-1));
  $('zNext').addEventListener('click', () => step(1));
  let sx = null;
  $('zoomStage').addEventListener('pointerdown', (e) => { sx = e.clientX; });
  $('zoomStage').addEventListener('pointerup', (e) => {
    if (sx == null) return; const dx = e.clientX - sx; sx = null;
    if (Math.abs(dx) > 50 && derive(S).over) step(dx < 0 ? 1 : -1);
  });

  /* ---------------- Sheets (help, verdict, copy fallback) ---------------- */
  const scrim = $('scrim');
  let openSheet = null;
  function showSheet(el, instant) {
    lastFocus = document.activeElement;
    openSheet = el; scrim.hidden = false; el.hidden = false; el.style.removeProperty('--drag');
    const go = () => { scrim.classList.add('is-shown'); el.classList.add('is-shown'); };
    if (instant || reduced()) go(); else requestAnimationFrame(() => requestAnimationFrame(go));
    const f = el.querySelector('button:not([disabled]), textarea');
    if (f && !instant) setTimeout(() => f.focus({ preventScroll: true }), 50);
  }
  function hideSheet(cb) {
    const el = openSheet; if (!el) return;
    openSheet = null;
    el.classList.add('is-closing'); el.classList.remove('is-shown'); el.style.removeProperty('--drag');
    scrim.classList.remove('is-shown');
    setTimeout(() => { el.hidden = true; scrim.hidden = true; el.classList.remove('is-closing'); if (cb) cb(); }, reduced() ? 0 : 240);
    if (lastFocus) lastFocus.focus({ preventScroll: true });
  }
  /* Dismissing the verdict sheet any way (scrim, Esc, drag) still copies the result, without a verdict — same as today. */
  function dismissSheet() {
    const wasVerdict = openSheet === $('verdictSheet');
    hideSheet(() => { resetVerdict(); if (wasVerdict) copyResult(); });
  }
  scrim.addEventListener('click', dismissSheet);
  document.querySelectorAll('[data-close]').forEach((b) => b.addEventListener('click', () => hideSheet()));
  $('helpBtn').addEventListener('click', () => showSheet($('helpSheet')));

  /* Drag the handle down to dismiss. */
  document.querySelectorAll('.sheet__grab').forEach((g) => {
    let y0 = null, t0 = 0, dy = 0;
    g.addEventListener('pointerdown', (e) => { y0 = e.clientY; t0 = performance.now(); dy = 0; g.setPointerCapture(e.pointerId); openSheet && openSheet.classList.add('is-dragging'); });
    g.addEventListener('pointermove', (e) => { if (y0 == null || !openSheet) return; dy = Math.max(0, e.clientY - y0); openSheet.style.setProperty('--drag', dy + 'px'); });
    g.addEventListener('pointerup', () => {
      if (y0 == null || !openSheet) return; y0 = null;
      openSheet.classList.remove('is-dragging');
      const v = dy / Math.max(1, performance.now() - t0);
      if (dy > 90 || v > 0.6) dismissSheet(); else openSheet.style.removeProperty('--drag');
    });
  });

  /* Keyboard: Esc closes the top layer; ←/→ step photos in the zoom after the game; Tab is trapped in dialogs. */
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { if (openSheet) dismissSheet(); else if (!zoom.hidden) closeZoom(); }
    if (!zoom.hidden && derive(S).over && (e.key === 'ArrowLeft' || e.key === 'ArrowRight')) step(e.key === 'ArrowRight' ? 1 : -1);
    if (e.key === 'Tab') {
      const box = openSheet || (!zoom.hidden ? zoom : null);
      if (!box) return;
      const f = [...box.querySelectorAll('button:not([disabled]), textarea, a[href]')].filter((x) => x.offsetParent !== null);
      if (!f.length) return;
      const i = f.indexOf(document.activeElement);
      if (e.shiftKey && i <= 0) { e.preventDefault(); f[f.length - 1].focus(); }
      else if (!e.shiftKey && i === f.length - 1) { e.preventDefault(); f[0].focus(); }
    }
  });

  /* ---------------- Share + verdict ---------------- */
  const VERDICT_TEXT = { steal: 'Steal 🤑', fair: 'Fair price 🤝', rip: 'RIP-OFF 🚨' }; // keep the app's existing strings
  function shareText() {
    const d = derive(S);
    const squares = [0, 1, 2, 3, 4, 5].map((i) => i < d.n ? (i === d.winIdx ? '🟩' : '🟥') : '⬜').join(' ');
    const lines = ['Guess My Casa ' + HOUSE.shareFlag, HOUSE.shareFlag + ' ' + squares];
    if (d.exact) lines.push('🎯 RIGHT ON THE MONEY! (0% off)');
    else if (d.won) lines.push('🎯 I was ' + Math.round(pct(S.g[d.winIdx]) * 100) + '% off');
    else lines.push('Look how much I suck!');
    if (S.verdict) lines.push('🧾 My verdict: ||' + VERDICT_TEXT[S.verdict] + '||');
    lines.push(location.origin + location.pathname + '?day=' + HOUSE.dayParam);
    return lines.join('\n');
  }
  let toastT = null, copiedT = null;
  function toast(msg) {
    const t = $('toast');
    t.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
    t.appendChild(document.createTextNode(msg));
    t.classList.remove('is-hiding'); t.classList.add('is-shown');
    clearTimeout(toastT);
    if (!FROZEN) toastT = setTimeout(() => { t.classList.add('is-hiding'); t.classList.remove('is-shown'); }, 2500);
  }
  function setCopied(on) {
    $('shareBtn').classList.toggle('is-copied', on);
    $('shareLabel').textContent = on ? 'Copied!' : 'Share result';
  }
  function copyResult() {
    const text = shareText();
    const ok = () => {
      setCopied(true); toast('Result copied — paste it anywhere');
      clearTimeout(copiedT); copiedT = setTimeout(() => setCopied(false), 2500);
    };
    const fallback = () => { $('copyBox').value = text; showSheet($('copySheet')); setTimeout(() => $('copyBox').select(), 80); };
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(text).then(ok, fallback);
    else fallback();
  }
  $('shareBtn').addEventListener('click', () => {
    if (HOUSE.hasVerdictQuestion && !S.verdict) showSheet($('verdictSheet')); else copyResult();
  });
  const vBtns = [...document.querySelectorAll('.verdict__opt')];
  function resetVerdict() { vBtns.forEach((b) => b.classList.remove('is-chosen', 'is-dimmed')); }
  vBtns.forEach((b) => b.addEventListener('click', () => {
    if (S.verdict && openSheet !== $('verdictSheet')) return;
    S.verdict = b.dataset.v;
    vBtns.forEach((x) => { x.classList.toggle('is-chosen', x === b); x.classList.toggle('is-dimmed', x !== b); });
    setTimeout(() => hideSheet(() => { resetVerdict(); copyResult(); }), reduced() ? 0 : 500);
  }));
  $('skipVerdict').addEventListener('click', () => hideSheet(() => { resetVerdict(); copyResult(); }));

  /* ---------------- Theme toggle ---------------- */
  function syncThemeUi() {
    const dark = root.getAttribute('data-theme') !== 'light';
    $('themeBtn').setAttribute('aria-label', dark ? 'Switch to light mode' : 'Switch to dark mode');
    document.querySelector('meta[name="theme-color"]').setAttribute('content', getComputedStyle(root).getPropertyValue('--theme-color').trim());
  }
  $('themeBtn').addEventListener('click', () => {
    const next = root.getAttribute('data-theme') === 'light' ? 'dark' : 'light';
    if (!reduced()) root.classList.add('theming');
    root.setAttribute('data-theme', next);
    try { localStorage.setItem('gmc-theme', next); } catch (e) {}
    syncThemeUi();
    setTimeout(() => root.classList.remove('theming'), 420);
  });

  /* ---------------- Confetti (canvas) + loss rain ---------------- */
  function confetti(exact) {
    if (!FX || reduced()) return;
    const cv = $('fx'), ctx = cv.getContext('2d'), dpr = window.devicePixelRatio || 1;
    const W = innerWidth, H = innerHeight;
    cv.width = W * dpr; cv.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const cs = getComputedStyle(root);
    const cols = COUNTRIES[CC].flag.concat([cs.getPropertyValue('--accent').trim(), cs.getPropertyValue('--ok').trim()]);
    const parts = [];
    const burst = (x, y, ang, spread, count, vmin, vmax) => {
      for (let i = 0; i < count; i++) {
        const a = (ang + (Math.random() - 0.5) * spread) * Math.PI / 180, v = vmin + Math.random() * (vmax - vmin);
        parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, w: 6 + Math.random() * 5, h: 9 + Math.random() * 7,
          r: Math.random() * 6.28, vr: (Math.random() - 0.5) * 0.3, wob: Math.random() * 6.28, c: cols[i % cols.length] });
      }
    };
    burst(-10, H * 0.62, -58, 40, 70, 11, 19);
    burst(W + 10, H * 0.62, -122, 40, 70, 11, 19);
    if (exact) burst(W / 2, H * 0.42, -90, 360, 180, 6, 15);
    const t0 = performance.now(), life = 3600;
    (function frame(now) {
      const el = now - t0;
      ctx.clearRect(0, 0, W, H);
      const fade = el > life - 600 ? Math.max(0, (life - el) / 600) : 1;
      parts.forEach((p) => {
        p.vy += 0.32; p.vx *= 0.985; p.vy *= 0.985; p.x += p.vx; p.y += p.vy; p.r += p.vr; p.wob += 0.18;
        ctx.save(); ctx.globalAlpha = fade; ctx.translate(p.x, p.y); ctx.rotate(p.r); ctx.scale(1, Math.cos(p.wob));
        ctx.fillStyle = p.c; ctx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); ctx.restore();
      });
      if (el < life) requestAnimationFrame(frame); else ctx.clearRect(0, 0, W, H);
    })(t0);
  }
  function rain() {
    if (!FX || reduced()) return;
    const box = $('rain'); let k = 0;
    const svg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M17 14V2M9 18.12L10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22a3.13 3.13 0 0 1-3-3.88z"/></svg>';
    const iv = setInterval(() => {
      for (let i = 0; i < 4; i++) {
        const w = document.createElement('div');
        w.innerHTML = svg; const s = w.firstChild; const size = 22 + Math.random() * 14;
        s.setAttribute('width', size); s.setAttribute('height', size);
        s.style.left = Math.random() * (innerWidth - size) + 'px';
        s.style.setProperty('--d', (1.5 + Math.random() * 0.9) + 's');
        s.style.setProperty('--r0', (Math.random() * 60 - 30) + 'deg');
        s.style.setProperty('--r1', (Math.random() * 120 - 60) + 'deg');
        s.addEventListener('animationend', () => s.remove());
        box.appendChild(s);
      }
      if (++k >= 12) clearInterval(iv);
    }, 150);
  }

  /* ---------------- Countdown to 10:00 Europe/Kyiv ---------------- */
  function secondsToReset() {
    const parts = new Intl.DateTimeFormat('en-GB', { timeZone: 'Europe/Kyiv', hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }).formatToParts(new Date());
    const g = (t) => Number(parts.find((p) => p.type === t).value);
    let diff = 10 * 3600 - ((g('hour') % 24) * 3600 + g('minute') * 60 + g('second'));
    if (diff <= 0) diff += 86400;
    return diff;
  }
  function tick() {
    const s = FROZEN ? 79198 : secondsToReset();
    const txt = [Math.floor(s / 3600), Math.floor((s % 3600) / 60), s % 60].map((v) => String(v).padStart(2, '0')).join(':');
    ['countdown', 'countdown2', 'countdown3'].forEach((id) => { const el = $(id); if (el) el.textContent = txt; });
  }
  tick(); if (!FROZEN) setInterval(tick, 1000);

  /* ---------------- Boot ---------------- */
  syncThemeUi();
  render();
  if (S.overlay === 'zoom') openZoom(true);
  if (S.overlay === 'help') showSheet($('helpSheet'), true);
  if (S.overlay === 'verdict') showSheet($('verdictSheet'), true);
  if (S.copied) { setCopied(true); toast('Result copied — paste it anywhere'); }
  if (derive(S).over) setTimeout(startAutoplay, 1500);
  requestAnimationFrame(() => requestAnimationFrame(() => app.classList.remove('no-anim')));

  window.GMC = {
    state: () => JSON.parse(JSON.stringify(S)),
    guess: (v) => { S.input = String(v); submitGuess(); },
    type: (v) => { input.value = String(v); input.dispatchEvent(new Event('input')); }
  };
})();
