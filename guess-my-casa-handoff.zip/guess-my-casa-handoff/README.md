# Guess My Casa: redesign handoff for Claude Code

This package holds everything a Claude Code session needs to implement the approved **Guess My Casa** redesign in the existing *Guess The House* codebase.

## Changelog

- **v2 (5 Nov 2026):** the clue is now a **clue pill** above the photo, replacing the strip in the photo's corner. It overlaps the photo's top edge and hangs past its left edge (the photo shifts 6px right, still 4:3). It uses the Clues drawer's surface colour, is rounded on both ends, and has a drawn magnifying glass. The magnifier also marks the Clues bar and every clue tile. The zoom button now uses an expand icon. The prototype, specs, screenshots, filmstrips and videos are all updated.
- **v1 (4 Nov 2026):** first handoff.

## How to use it

1. Unzip it at the **root of the repo**. It creates a `guess-my-casa-handoff/` folder. Add that folder to `.gitignore` if you don't want it committed.
2. Start a Claude Code session in the repo and send:

   ```text
   Read guess-my-casa-handoff/PROMPT.md and follow it exactly. It is the full brief for redesigning this game into "Guess My Casa". Start with Phase 0, and don't change any code until you've written REDESIGN-NOTES.md with the component mapping.
   ```

3. Let it work through phases 0–6. It checks itself against `spec/09-acceptance-checklist.md` at the end.

## What's inside

```
PROMPT.md                      ← the master instructions (start here)
spec/
  01-design-decisions.md       what changes, what stays, old → new map
  02-tokens.md + tokens.css    colours, type, sizes, z-index, easing
  03-layout-and-components.md  every component, measured
  04-motion.md                 every animation, timed and choreographed
  05-screens-and-states.md     index of all screenshots and filmstrips
  06-edge-cases.md             ~60 edge cases with required behaviour
  07-theming-countries-seasons.md
  08-copy.md                   every string, including the share text
  09-acceptance-checklist.md   QA list
reference/
  prototype/                   runnable HTML/CSS/JS reference (open index.html via a local server)
  design-canvas/Casa.dc.html   the approved mock's source
screenshots/                   41 rendered screens (mobile, small phone, desktop, light/dark, countries, Halloween, motion moments)
motion/                        16 frame-by-frame filmstrips of every animation (what Claude Code "watches")
videos/                        6 MP4 screen recordings of the same flows (for you)
context/ORIGINAL-DESIGN-BRIEF.md  the original brief describing today's game
```

## Try the prototype yourself

```bash
cd reference/prototype
python3 -m http.server 8123
```

Then open:

```text
http://localhost:8123/?screen=start
```

Type guesses (the price is €800,000), open Clues, tap the circles, toggle the theme, then win and share. Add `&country=pt`, `&mode=light` or `&season=halloween` to see the variants.
