# Implement the "Guess My Casa" redesign

You are working in the codebase of a live daily browser game currently called **Guess The House**: a Wordle-style game where everyone gets the same European house each day and has 6 tries to guess its asking price. It is a **static React + Tailwind site** with no backend: Leaflet/OpenStreetMap for the map, `canvas-confetti` for effects, all game state in `localStorage`, and write-only analytics to a Google Sheet.

This package is a complete, owner-approved redesign. Implement it in the existing codebase **accurately, without breaking anything that works today**. Everything you need is in this folder. Read it before you change any code.

---

## 0. What is in this package

| Path | What it is | How to use it |
|---|---|---|
| `PROMPT.md` | This file: the task, the process, the rules | Follow it top to bottom |
| `spec/01-design-decisions.md` | What changes, what stays, and why | Read first |
| `spec/02-tokens.md` + `spec/tokens.css` | Every colour, size, radius, z-index, easing and duration | Copy `tokens.css` into the app as the single source of truth |
| `spec/03-layout-and-components.md` | Anatomy, measurements, states and behaviour of every component | Build from this |
| `spec/04-motion.md` | Every transition and animation, with timings and choreography | **The most important spec.** Motion is part of the game's personality |
| `spec/05-screens-and-states.md` | Index of every screen and state, with screenshots | Use it to check your work |
| `spec/06-edge-cases.md` | Everything that can go wrong and what to do | Handle all of it |
| `spec/07-theming-countries-seasons.md` | Dark/light mode, per-country accents, seasonal overrides | Required for the multi-country plan |
| `spec/08-copy.md` | Every user-facing string, including the share text | Use it verbatim |
| `spec/09-acceptance-checklist.md` | QA checklist | Tick every line before you finish |
| `reference/prototype/` | **Runnable reference prototype** (vanilla HTML/CSS/JS, no build) that shows the exact look and every animation | Open it in a browser (see 0.1). Copy CSS values and keyframes from it |
| `reference/design-canvas/Casa.dc.html` | The approved mock's source from the design tool | Secondary reference only |
| `screenshots/` | 41 rendered screens (390×844 @2x phones, 320px phone, 1280px desktop, light/dark, countries, Halloween, motion moments) | Your visual target |
| `motion/` | 16 **filmstrips**: frame-by-frame images of each animation with ms timestamps | Read these to *see* the motion (you can't play video) |
| `videos/` | The same flows as MP4 for the human owner | Optional |
| `context/ORIGINAL-DESIGN-BRIEF.md` | The owner's description of the current game, its rules, quirks and "must not break" list | Read it. It describes what exists today |

### 0.1 Running the reference prototype

From the package root:

```bash
cd reference/prototype && python3 -m http.server 8123
```

Then open `http://localhost:8123/?screen=mid`. Useful URL params: `screen=start|typing|invalid|mid|clues|review|last|zoom|help|win|exact|loss|zoomEnd|verdict|copied|pastday|nopuzzle`, `mode=dark|light`, `country=it|es|pt|fr|gr`, `season=halloween`, `frozen=1` (fixed countdown), `fx=0` (no confetti or autoplay). In the console, `GMC.guess(780000)` plays a guess (the mock price is €800,000).

**The prototype is a reference for look, structure and motion only.** Its game rules, storage and data are simplified stand-ins. Never replace the app's existing rule logic, storage format or data loading with the prototype's.

---

## 1. Ground rules (non-negotiable)

These come from the owner's brief, section 8. Breaking any of them is a failed task.

1. **The share text never contains a euro amount**, and the verdict stays behind the `||spoiler||` markup. The only change to the share text is the first line's name: `Guess The House` becomes `Guess My Casa` (spec/08-copy.md).
2. **The price stays hidden until the game ends.** Nothing (DOM, aria-label, title attribute, count-up start value) may reveal it earlier.
3. **One photo and one hint per wrong guess, 6 of each.** Do not change the rules: ±10% wins, double arrows at >30%, exact-price celebration, 6 tries. Reuse the existing rule functions. Do not re-implement them.
4. **Adding a house needs no code change.** Don't introduce per-house hand-tuned content. Country and theme come from data the house config already has (spec/07).
5. **Layouts must cope with imperfect photos** (watermarks, odd aspect ratios, animated WebP) **and hints of any length.**
6. **Overlays sit above the map.** Leaflet uses z-index up to 1000. Use the z-index tokens (sheets 1210, zoom 1220, toast 1300).
7. **Motion is part of the personality.** Sharpen it, don't remove it. But respect `prefers-reduced-motion` fully (spec/04 §10).
8. **Saved games keep working.** Existing `localStorage` keys and formats stay readable. A player midway through today's house must be able to reload after your deploy and continue. Any new stored field is additive and optional.
9. **Existing features keep working:** `?day=` past-day links, the 10:00 Europe/Kyiv reset with auto-reload, the countdown, the bonus link, disguised-country houses, seasonal theming, the verdict question on houses that have one (and only on those), analytics events, and link-preview meta tags.
10. **Intentional jokes stay** (brief §1 "Tone"): "You suck!" / "Look how much I suck!", the 🇮🇪 share flag mix-up, and the "Italian 🥐 house" page description. Don't "fix" them.

---

## 2. The change in one paragraph

Replace the current dark-navy/green Tailwind look with **"Guess My Casa"**. It has a Mediterranean café look: a striped, scalloped awning across the top, Fraunces serif headings with a Manrope UI font, and per-country accent colours. **Dark mode is the default** (deep night blue); **light mode** (warm limewash cream) is a toggle that remembers the choice.

The layout becomes simpler and more stable, so the guess input never moves down as hints arrive:

- **Header:** title, theme toggle, help button, then a flag chip ("Casa Nº 153 · Italia") and the countdown.
- **Clue pill + photo (4:3):** the **current clue sits in a pill above the photo**. It overlaps the photo's top edge and hangs past its left edge, with a drawn magnifying glass on the left. The same magnifier marks the Clues bar and every clue tile.
- **Six try circles** that double as the guess history: an arrow inside the circle, the guessed value below it.
- **Price field:** a pill with the **Guess button inside it**.
- **Result card:** replaces the field when the game ends.
- **Clues:** a **collapsible panel** whose locked clues sit behind **closed window shutters** that swing open.
- Then the map, an in-content ad slot, the footer, and a sticky bottom anchor ad.
- **Overlays:** sheets for how-to-play, the price verdict and the copy fallback; a FLIP photo zoom; a top toast.

The separate guess list and the hints list are removed. All their information now lives in the circles, the photo overlay and the clues panel.

---

## 3. Process

Work in this order. Commit after each phase with a clear message. If the repo has tests, run them after every phase.

### Phase 0: Understand before touching anything
1. Read `spec/01` to `spec/09` and `context/ORIGINAL-DESIGN-BRIEF.md`. Look at every image in `screenshots/` and `motion/`.
2. Explore the repo and write `REDESIGN-NOTES.md` at its root. Map **every existing component and state** to its new counterpart (use the table in `spec/01-design-decisions.md` §3). Record:
   - where the rules, storage, share-text builder, countdown/reset, analytics calls, seasonal theme, disguised-country config and Leaflet setup live
   - the existing `localStorage` keys
3. Run the app and the existing build, lint and tests. Note anything already broken, so you don't get blamed for it or "fix" it by accident.
4. Create a branch, e.g. `redesign/guess-my-casa`.

### Phase 1: Foundations
1. **Copy** what the app needs out of this package into the app's own source tree (never import from the package folder at runtime; it may be git-ignored). Add `spec/tokens.css` to the app as the token source. Map Tailwind's theme to the CSS variables (e.g. `colors: { bg: 'var(--bg)', accent: 'var(--accent)', … }`) so components use tokens, not hex values or Tailwind palette colours.
2. Self-host the fonts (Fraunces variable with the `opsz` and `wght` axes; Manrope variable). The `.woff2` files are in `reference/prototype/fonts/`. Use `font-display: swap` and preload the two Latin files.
3. Theme plumbing:
   - Set `data-theme` (default `dark`), `data-country` and the optional `data-season` on `<html>`.
   - Add the no-flash inline script from `reference/prototype/index.html` to `index.html`, before the CSS.
   - Remember the choice in `localStorage` under a new key `gmc-theme`.
   - Update `<meta name="theme-color">` whenever the theme changes.
4. Country plumbing: derive the country code from the existing per-house disguise data (spec/07 §2). Default to `it`.
5. Migrate the existing seasonal theme (Halloween) to set `data-season="halloween"`. The token overrides are in `tokens.css`. Its special effects (fog, cobwebs, candle flicker, candy confetti, ghost rain, Creepster title) keep working on top of the new layout (spec/07 §4).

### Phase 2: Static layout (no motion yet)
Build each component in `spec/03` in page order:
1. sticky past-day banner
2. awning
3. header (title, theme toggle, help button)
4. meta row (country chip, which is also the bonus link, and the countdown)
5. clue pill + photo with the photo buttons
6. try circles
7. guess form
8. result card
9. clues panel
10. map
11. in-content ad
12. footer
13. sticky anchor ad
14. the "no casa today" screen

Remove the old hints list or column, the old guess list, the title icon and the old try buttons. Their behaviour is now covered by the new components. Check each against its screenshot at 390×844 in both themes before moving on.

### Phase 3: Overlays
Photo zoom, the three bottom sheets (help, verdict, copy fallback) and the toast. Include focus management, focus trapping, Escape to close, scroll lock, swipe-to-dismiss on sheets, and swipe and arrow keys in the zoom after the game ends.

### Phase 4: Motion
Implement everything in `spec/04-motion.md`, event by event, comparing against `motion/*.jpg` and the prototype. Copy the keyframes and timings from `reference/prototype/styles.css`. Use CSS transitions and keyframes where possible. Use `canvas-confetti` with the settings in spec/04 §6. Don't add an animation library unless the repo already has one.

### Phase 5: Edge cases, accessibility, reduced motion
Work through `spec/06-edge-cases.md` and the accessibility section of `spec/03` line by line.

### Phase 6: Verify
1. Build, lint and test.
2. Use Playwright or the repo's e2e tool to render each state from `spec/05` at 390×844 (DPR 2), 320×640 and 1280×900, in dark and light. Compare them side by side with `screenshots/`. Fix the differences.
3. Play a full game to a win, an exact win and a loss. Reload a finished game and a half-finished game. Open a `?day=` link. Toggle the theme mid-game. Try every country and Halloween (you'll need to fake the date or the config).
4. Go through `spec/09-acceptance-checklist.md` and tick every item in `REDESIGN-NOTES.md`.
5. Write a short summary in `REDESIGN-NOTES.md` of what changed, any deviation from the spec and why, and anything the owner should check.

---

## 4. Decisions already made (don't ask again, just implement)

- **Name:** "Guess My Casa" everywhere the old name appears: page `<title>`, the `og:` and `twitter:` titles, the visible title and the first line of the share text. The meta *description* keeps its joke.
- **Dark is the default for everyone**, regardless of OS setting. Light is opt-in and remembered.
- **Tassos (the agent portrait):** the owner said to ignore him for design purposes, so the verdict sheet does not show him. Don't delete the image asset.
- **Title icon:** replaced by the flag chip in the meta row. The chip is the bonus link (opens the house's YouTube link in a new tab), and the footer also has a "bonus link". Disguised houses show the disguise country's flag, name and word for "house".
- **Desktop:** the same single column, max 440px wide, centred. The awning runs full-bleed. No side columns.
- **Clues:** the current photo's clue shows in the **clue pill** above the photo (spec/03 §4: exact position, colours and icon; the owner iterated on it, so match it precisely). All unlocked hints are in the collapsible Clues panel, which is closed by default and doesn't remember its state across reloads.
- **Guess history:** lives in the circles and stays visible after the game ends (fixes brief §9).
- **New input feedback:**
  - guesses below €10,000 show "Enter the full price, e.g. 450,000"
  - a repeated guess shows "You already tried €X" and does not use up a try
  - non-digits are stripped as you type, and the value formats live as `450,000`
- **Celebrations play once**, when the game ends in that session, not on every reload (fixes brief §9).
- **Clipboard failure** opens the copy-fallback sheet with the text selected (fixes brief §9).
- **Map mouse wheel:** the wheel only zooms after the map is clicked or focused (fixes brief §9).
- **Ads:** two placeholder slots with reserved size (spec/03 §12). Real ad tags are out of scope. Hide the slots when ads are disabled.

If something in the codebase contradicts the spec in a way these decisions don't cover, choose the option that keeps existing behaviour working, write it down in `REDESIGN-NOTES.md`, and continue.

---

## 5. Definition of done

- Every screen in `spec/05` matches its screenshot closely: same structure, tokens, spacing (within a few px) and type.
- Every animation in `spec/04` is implemented with the specified timing and easing, matches its filmstrip, and degrades correctly under reduced motion.
- Every item in `spec/09-acceptance-checklist.md` passes.
- The rules in section 1 are intact. Saved games from before the deploy load and play correctly.
- Build, lint and tests pass. No console errors. No layout shift when ads, fonts or images load. Lighthouse accessibility ≥ 95 on mobile.
- `REDESIGN-NOTES.md` documents the mapping, any deviations and anything left for the owner.
