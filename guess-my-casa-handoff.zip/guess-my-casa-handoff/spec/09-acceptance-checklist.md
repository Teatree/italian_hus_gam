# 09 · Acceptance checklist

Copy this list into `REDESIGN-NOTES.md` and tick every item. Test at 390×844 (DPR 2), 320×640 and 1280×900, in Chrome and in a WebKit/Safari engine (Playwright `webkit` is fine).

## Must not break (from the brief)
- [ ] The share text contains no "€" and none of the price's digits (unit test, or a manual check for win, exact and loss).
- [ ] The verdict is wrapped in `||…||`. Houses without the question copy straight away.
- [ ] The price is not in the DOM, aria-labels, titles or the count-up before the game ends.
- [ ] One photo and one hint per wrong guess, 6 of each. The thresholds and arrows are unchanged (compare 10 sample guesses with the previous build).
- [ ] A save from before the deploy loads mid-game and finished.
- [ ] `?day=` links open the right house, save separately, show the banner and hide the countdown.
- [ ] The 10:00 Europe/Kyiv reset still auto-reloads. The countdown is right in another time zone (test with Playwright `timezoneId: 'America/New_York'`).
- [ ] Disguised houses show the right flag, name and word in the chip, with the right accent.
- [ ] The Halloween season (fake the date or config) applies the token override, its effects, and themed sheets.
- [ ] Every analytics event that fired before still fires (diff the calls).
- [ ] The jokes are intact: "You suck!", "Look how much I suck!", the 🇮🇪 flag, and the meta description.
- [ ] All overlays appear above the Leaflet map.

## Layout and visuals
- [ ] Each screen in spec/05 matches its screenshot (structure, colours, type, spacing within a few px).
- [ ] The awning is full-bleed with correct scallops at 320, 390, 1280 and 1920px.
- [ ] The clue pill sits above the photo, overlaps its top edge by ~12px, starts 12px left of the photo's left edge, is rounded on both ends, uses the Clues drawer's surface colour, has the drawn magnifier on the left, and shows max 2 lines. The photo is shifted 6px right and is still 4:3.
- [ ] The same magnifier appears in the Clues bar and on every unlocked tile; the zoom button uses the expand icon.
- [ ] A new hint does **not** move anything below the photo. The page height stays the same before and after a wrong guess, with the Clues panel open or closed.
- [ ] The input position is the same on try 1 and try 6.
- [ ] The circles show arrows inside and values below. The guess history is still visible after the game ends.
- [ ] The Clues panel is collapsed by default, opens and closes with a click and the keyboard, has 6 fixed-height tiles and shutters on locked clues.
- [ ] The result card replaces the form, with the right title, colour, price and line for win, exact and loss.
- [ ] Dark is the default on a first visit, even with OS light mode. Light persists across reloads. No flash on load.
- [ ] Every country's accent and shutter colours are right in dark and light.
- [ ] 320px: the header stays on one line, there are 6 circles, and the verdict tiles don't wrap.
- [ ] Desktop: centred 440px column; sheets centred at max 440px.
- [ ] Ad slots reserve their space with no layout shift. With ads disabled, there are no boxes and no reserved bottom padding.
- [ ] Map: the dark tile filter applies to tiles only, the accent pin follows the theme and country, and the wheel doesn't hijack page scrolling.

## Motion (compare with `motion/*.jpg` and the prototype)
- [ ] Wrong guess: colour change → arrow pop (180ms) → label rise (260ms) → next "now" bounce (250ms), photo crossfade, clue pill slide-in + magnifier wiggle, dot pop, shutter swing (if the panel is open).
- [ ] Invalid input: shake + error. No try used.
- [ ] Clues panel expand and collapse, with the chevron rotating.
- [ ] Reviewing an earlier try: crossfade, clue text swap, ring, Back chip slide.
- [ ] Last try: the breathing glow.
- [ ] Win: form out → card rises → title stamp → count-up → Share rise; confetti in flag colours; shutter cascade 450ms apart; unused circles fade at 2s; autoplay starts at about 4s.
- [ ] Exact: extra centre burst; accent title.
- [ ] Loss: thumbs-down rain (12×4, every 150ms); stamp + wobble.
- [ ] Share → verdict sheet slide-up; choosing → the tile springs, the others dim; the sheet closes at 500ms; toast + "Copied!" for 2.5s.
- [ ] Sheets: drag to dismiss, scrim tap, Escape. Dismissing the verdict sheet copies without a verdict.
- [ ] Zoom: FLIP open and close; arrows, swipe and ←/→ after the game; autoplay pauses while open.
- [ ] Theme toggle: the whole page cross-fades over 280ms; the icon rotates.
- [ ] No animation at all on first paint or when restoring a finished game. Celebrations never replay on reload.
- [ ] Reduced motion: no confetti, rain, bounce, shake, slide, FLIP, autoplay or count-up; colour and opacity changes remain.
- [ ] No dropped frames on a mid-range phone (Chrome DevTools, 4× CPU throttle): only transform and opacity animate.

## Edge cases (spec/06)
- [ ] C1–C12, I1–I13, P1–P10, S1–S6, L1–L9, M1–M4, A1–A6 are all checked and ticked.

## Accessibility
- [ ] Every target is ≥ 44×44.
- [ ] Focus is visible everywhere and trapped in dialogs; focus returns on close.
- [ ] Screen reader: guess feedback, the result and the toast are announced.
- [ ] Lighthouse accessibility ≥ 95 (mobile), with no contrast failures.

## Engineering
- [ ] Build, lint and tests pass; no console errors or warnings.
- [ ] No new runtime dependencies, apart from self-hosted font files.
- [ ] Timers, intervals and listeners are cleaned up on unmount; countdown intervals pause while the tab is hidden.
- [ ] `REDESIGN-NOTES.md` covers the mapping, the decisions, deviations and anything left for the owner.
