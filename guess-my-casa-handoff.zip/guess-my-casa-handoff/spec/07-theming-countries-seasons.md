# 07 · Theming: modes, countries, seasons

Three independent attributes on `<html>` select the tokens. Components never branch on them in JS for colours. The only exceptions are canvas confetti colours and the Leaflet `divIcon`, which read the computed CSS variables.

```html
<html lang="en" data-theme="dark" data-country="it" data-season="halloween">
```

## 1. Dark / light

- **Default is dark for every player**, even if the OS prefers light. This is the owner's decision.
- The toggle saves `gmc-theme` (`dark` | `light`). Read it in an inline `<head>` script before the CSS so there's no flash (copy it from `reference/prototype/index.html`).
- Keep `<meta name="theme-color">` in sync (`--theme-color`: `#121A26` dark, `#FAF3E6` light) so the mobile browser chrome matches.
- `color-scheme: dark | light` is set by the tokens, so native form controls and scrollbars match.
- The toggle is hidden while a season is active (seasons are designed dark-only). The saved preference is kept and applies again after the season ends.

## 2. Countries

The house config already decides the "disguise" country through its title icon and share flag (brief §1; `29-title-icon-*`: Italy default, Spain, Greece, Finland). Find that field in the codebase and map it to a country code:

```ts
const COUNTRY = {
  it: { name: 'Italia',   word: 'Casa',   flag: ['#009246', '#F4F5F0', '#CE2B37'] },
  es: { name: 'España',   word: 'Casa',   flag: ['#AA151B', '#F1BF00', '#AA151B'] },
  pt: { name: 'Portugal', word: 'Casa',   flag: ['#046A38', '#DA291C', '#FFE900'] },
  fr: { name: 'France',   word: 'Maison', flag: ['#0055A4', '#F4F5F0', '#EF4135'] },
  gr: { name: 'Hellas',   word: 'Spíti',  flag: ['#0D5EAF', '#F4F5F0', '#0D5EAF'] },
  fi: { name: 'Suomi',    word: 'Talo',   flag: ['#002F6C', '#F4F5F0', '#002F6C'] },
} as const;
// countryOf(house) → 'it' | … ; unknown or missing → 'it'
```

The country controls:
- `data-country` (the accent, shutter colour and CSS flag in the chip)
- the chip text "{word} Nº {n} · {name}"
- the confetti colours
- the map pin colour (it follows the accent)

It does **not** change the share flag. That keeps using the existing logic, including the intentional 🇮🇪 joke.

The **page title, meta and share title stay "Guess My Casa"** for every country. The word "Casa" in the brand is fixed; only the chip uses the local word.

## 3. What the accent touches

The awning stripe and scallops, the "now" circle (fill + glow), the Guess / Share / Let's play buttons, the past-day banner, the "Back to try" chip, links, the field ring on focus, clue numbers and NEW tags, the selected-tile ring, lit clue dots, help badges, the chosen verdict tile, the exact-price title, and the map pin.

It does **not** touch: wrong (miss), right (ok), body text, or surfaces.

## 4. Seasons

Seasons are token overrides plus optional effect layers. They switch on and off with the house date, exactly as the Halloween theme does today (27–31 October).

```css
[data-season="halloween"] { /* full token override, see tokens.css */ }
```

When migrating the existing Halloween implementation:

| Existing Halloween effect (brief §3, 23–28) | In the new design |
|---|---|
| Near-black purple palette, orange buttons | `data-season="halloween"` tokens (already in `tokens.css`) |
| Creepster font | Title only: `[data-season="halloween"] .title { font-family: 'Creepster', var(--font-display); }` |
| Cobwebs, drifting fog (45s / 70s loops) | Keep as decorative layers behind the column (`z-index` below content, `pointer-events: none`); respect reduced motion as today |
| 🕯️ hints | During the season the magnifying glass in the clue pill, Clues bar and tiles is replaced by 🕯️ (or a candle SVG) |
| Tombstone tries | Optional: circles stay circles; the "now" glow is orange. If the owner wants tombstones back, use `border-radius: 50% 50% 8px 8px` on the circles in the season |
| Candle flicker on each new photo (900ms) | Run it on the incoming photo layer during the crossfade |
| Purple night map, pumpkin pin | `--map-filter` override (in tokens) + a pumpkin `divIcon` in the season |
| 🍬🍭🎃 confetti | Season config overrides the confetti `shapes` (canvas-confetti `shapeFromText`) and colours |
| 👻🦇💀 loss rain | Season config overrides the rain glyphs |
| Verdict popup not themed (brief §9) | Fixed for free: sheets use the tokens |

Structure seasons as data, for example `SEASONS = { halloween: { from: '10-27', to: '10-31', titleFont: 'Creepster', hintPrefix: '🕯️', confetti: {...}, rainGlyphs: [...] } }`, so future seasons (Christmas, summer) are config, not code.

## 5. Theme × country × season matrix to test

Test at least: it/dark, it/light, es/light, pt/dark, fr/dark, gr/light, fi/dark, it/halloween. Screenshots for most of these are in `screenshots/30–41`.
