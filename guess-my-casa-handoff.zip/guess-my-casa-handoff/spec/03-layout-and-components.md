# 03 · Layout and components

Measurements are CSS px at a 390px-wide viewport. The reference implementation of each component is in `reference/prototype/` (`index.html` for structure, `styles.css` for exact values). Screenshots are in `screenshots/`.

## 0. Page structure (top to bottom)

```
[Past-day banner]   sticky, edge to edge, only on ?day= links
[Awning]            full-bleed, 37px
┌ column (max 440px, 16px gutters, centred) ───────────────┐
│ Header row:   Title ················· [☀] [?]            │  14px top padding
│ Meta row:     [flag  Casa Nº 153 · Italia]   New casa in 21:59:58 │  10px below
│ ── 16px ──                                               │
│   (clue pill)  ← sits above the photo, overlaps its top edge, hangs 12px past its left edge │
│ Photo 4:3 (radius 20), shifted 6px right, zoom bottom-right │
│ ── 16px ──                                               │
│ Try circles ×6 (grid, 4px gaps)                          │
│ ── 16px ──                                               │
│ Guess form  (or the Result card once the game is over)   │
│ ── 16px ──                                               │
│ Clues panel (collapsible)                                │
│ ── 16px ──                                               │
│ Map 180px + attribution                                  │
│ ── 16px ──                                               │
│ Ad 300×250 (labelled)                                    │
│ Footer                                                   │
└──────────────────────────────────────────────────────────┘
[Anchor ad 320×50]  fixed to the bottom, full-bleed bar 66px + safe area
```

The body gets `padding-bottom: calc(66px + env(safe-area-inset-bottom))` so the anchor ad never covers content. On a 390×844 phone the photo, circles and price field are all above the fold, and so is the Share button on the result card.

Everything is one column on every screen size. On desktop the column is centred, max 440px, and the awning and anchor bar span the full viewport width (`screenshots/51-desktop-mid.jpg`).

## 1. Past-day banner

Shown only when the URL has a valid past `?day=`. Matches `16-past-day-link`.

- **Position:** `position: sticky; top: 0; z-index: 1050`, edge to edge (outside the column), so it stays visible while scrolling.
- **Look:** background `--accent`, text `--on-accent`.
- **Layout:** padding `8px 8px 8px 16px`; a calendar icon (18px stroke), then "Casa from Sat 31 Oct" (14px/800, flex 1).
- **Button:** a pill link "Today's casa →", 44px tall, background `--on-accent`, text `--accent`. It navigates to the URL without `?day`.
- **Countdown:** hidden in the meta row, which shows the date ("Sat 31 Oct") instead.
- **Entrance:** slides down 320ms on first paint (spec/04).

## 2. Awning

Two stacked divs, pure CSS, no images (`aria-hidden`):
- **Stripes:** 24px tall, `repeating-linear-gradient(90deg, var(--accent) 0 26px, var(--stripe) 26px 52px)`.
- **Scallops:** 13px tall. Two radial-gradient layers, one `--accent` circle at x=13 and one `--stripe` circle at x=39, each repeating every 52px. The CSS is in `styles.css` → `.awning__scallops`.

It is full-bleed and repeats at any width. It recolours instantly when the country or theme changes, so it needs no JS.

## 3. Header

**Row:**
- **Title:** "Guess My Casa", Fraunces 29px/650, flex 1, on one line. At ≤360px viewport width it drops to 24px.
- **Theme toggle:** a 44px circle button with background `--raised`.
  - Its sun and moon icons (20px, stroke 2) are stacked in the same grid cell. The inactive one is at `opacity: 0; rotate(-90deg) scale(.6)`.
  - `aria-label` is "Switch to light mode" or "Switch to dark mode".
  - It is hidden while a season is active.
- **Help:** "?", a 44px circle button, Fraunces 20px/700. It opens the How-to-play sheet and has `aria-haspopup="dialog"`.

**Meta row** (14px, `--muted`, space-between):
- **Chip:** a pill with background `--surface`, padding `6px 12px 6px 8px`, min-height 32px.
  - It holds the flag (20×14, radius 3, `background: var(--flag)`) and the text "{Word} Nº {n} · {Country}" (700, `--text`).
  - The chip is an `<a>` to the house's **bonus link** (`target=_blank rel=noopener`, `aria-label="Bonus link"`). If the house has no bonus link, render a `<span>`.
  - If the house number can't be derived reliably from the data, render "{Word} · {Country}".
- **Countdown:** "New casa in **21:59:58**" (bold, tabular, `--text`).
  - At ≤360px the "New casa in" label is hidden and only the time shows.
  - On past-day links it shows the date instead.

## 4. Photo

- **Structure:** an **unclipped** `<figure>` (`position: relative; margin: 30px 0 0 6px`) holding (a) the photo frame and (b) the clue pill. The 30px top margin makes room for the pill above the photo; the 6px left margin shifts the photo right so the pill can stick out on the left.
- **Photo frame:** `aspect-ratio: 4/3`, radius 20, `overflow: hidden`, background `--raised` (shows while loading), shadow `--photo-shadow`. At 390px the frame is 352×264: it stays a 4:3 rectangle, it is just 6px narrower.
- **Two stacked `<img>`** with `object-fit: cover` for crossfades (spec/04 §2). The front one has `opacity: 1`. Animated WebP is fine: it just loops.
- Tapping the photo opens the zoom.

**Clue pill** (the owner's final design; see `screenshots/04-after-3-wrong-guesses.mobile.jpg`). It is a proper UI element, **not** an overlay strip on the photo:
- **Position:** absolutely positioned on the figure, outside the clipped frame: `top: -28px; left: -12px; z-index: 3`. It sits **above** the photo, its bottom ~12px overlaps the photo's top edge, and it starts **12px left of the photo's left edge** (about 10px from the screen edge on a 390px phone). The photo is shifted right and the pill left.
- **Shape:** a pill rounded on **both ends** (`border-radius: 999px`). Padding `8px 16px 8px 12px`, gap 8px, `max-width: min(300px, calc(100% - 12px))`.
- **Colours:** the **same surface as the Clues drawer**: background `--surface`, text `--text`, inner 1px ring `--line`.
- **Separation from the photo:** shadow `0 8px 22px rgba(0,0,0,.38)` (light: `rgba(58,42,32,.22)`) plus an outer `0 0 0 3px var(--bg)` ring.
- **Content:** the magnifying glass (22px, accent) on the far left, then the clue text (14px/700, line-height 1.25, **max 2 lines**, ellipsis). There is no "Clue n" label; the full text is always readable in the Clues panel.
- It shows the clue that belongs to **the photo being viewed** (clue n ↔ photo n). It is hidden (not just empty) if the clue is empty.
- `role="note"`, `aria-label="Clue 4 of 6: 110 m² of living space"`. Don't put `aria-live` on it while the carousel autoplays (spec/06).

**The magnifying-glass icon** (the clue symbol, used in three places: the clue pill, the Clues bar and each unlocked tile). It is a drawn magnifying glass, not an icon inside a button-like circle. Copy the SVG from `reference/prototype/index.html` (`.glass`):

```html
<svg class="glass" width="22" height="22" viewBox="0 0 24 24" aria-hidden="true">
  <circle cx="9.8" cy="9.8" r="6.6" fill="currentColor" fill-opacity="0.18" stroke="currentColor" stroke-width="2.3"/>  <!-- tinted glass lens + rim -->
  <path d="M6.6 8.6a3.6 3.6 0 0 1 2.9-2.4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" opacity="0.75"/>  <!-- glint (omit at 14px) -->
  <path d="M14.6 14.6l1.6 1.6" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/>  <!-- collar -->
  <path d="M16.9 16.9l4.3 4.3" stroke="currentColor" stroke-width="4.2" stroke-linecap="round"/>  <!-- thick handle -->
</svg>
```

Colour: `--accent` (`color: var(--accent)`). Sizes: 22px in the pill and the Clues bar, 14px without the glint on tiles. `transform-origin: 41% 41%` (the lens centre) for the wiggle animation.

**Photo buttons:** 44px circles, background `--overlay-ink`, white 20px icons.
- **Zoom:** bottom-right, 10px inset, an **expand icon** (four outward arrows, 18px). Not a magnifier, because the magnifier now means "clue". `aria-label="Enlarge photo"`, `aria-haspopup="dialog"`.
- **Prev/next:** vertically centred, 10px from the left and right edges. **Only after the game ends**: they fade in over 800ms and are `pointer-events: none` before that.
- **"Back to try N →" chip:** bottom-left, 44px tall, accent pill, 14px/800. It appears only while the player is reviewing an earlier try during play; tapping it returns to the current photo.

## 5. Try circles

An `<ol>` grid: `repeat(6, minmax(0, 1fr))`, gap 4px. Each item is a `<button>` laid out as a column (gap 6px) containing:
- a circle (`--circle`: 46px, or 40px on narrow phones)
- a label underneath (13px/700, min-height 18px)

| State | Circle | Content inside | Label below |
|---|---|---|---|
| `now` (current try) | fill `--accent`, no border; dark: `0 0 0 4px` halo + `0 0 22px` glow; light: `0 6px 14px` glow | number, 18px/800, `--on-accent` | "now" in `--accent` |
| `wrong` | 2px `--miss` border, fill `--miss-bg` | arrow `↑ ↑↑ ↓ ↓↓`, 16px/800, `--miss` | short value ("300k", "1.5M") in `--text` |
| `right` (winning guess) | fill and border `--ok` | check icon (22px, stroke 3), `--on-ok` | short value, 800, `--ok` |
| `locked` (future) | 1.5px **dashed** `--lock-ring` | number in `--dim` | "–" in `--dim` |
| `unused` (after a win) | 1.5px solid `--line`, fill `--surface`, opacity .7 | number in `--dim` | "–" |
| + `selected` (being viewed, when that isn't simply the current try) | adds the ring `0 0 0 3px var(--bg), 0 0 0 5px var(--text)` | | |
| + `last` (try 6 is `now`) | the glow "breathes" (spec/04 §3.4) | | |

Behaviour:
- **During play**, past circles and the current one are tappable and select that photo and hint. Future circles are `disabled`. **After the game** all six are tappable.
- **Short value format:** under €1M, `Math.round(v/1000)+'k'` ("650k"). From €1M, one decimal with a trailing ".0" removed ("1.5M", "2M", "12.3M").
- **Accessibility:**
  - `aria-label`: "Try 2: €1,500,000, far too high", "Try 4, current", "Try 5, locked", "Try 4: €780,000, within 10%".
  - `aria-current="true"` on the circle being viewed.
  - The arrow glyphs are decorative and covered by the aria-label.

**Arrow mapping** (reuse the app's existing logic): too low → ↑, too low by more than 30% → ↑↑, too high → ↓, too high by more than 30% → ↓↓.

## 6. Guess form (during play)

A `<form novalidate autocomplete="off">` so Enter submits.

- **Field:** a pill, 60px tall, radius 999, background `--surface`, padding `0 6px 0 22px`, gap 8px.
  - **Ring:** at rest `inset 0 0 0 1.5px var(--line)`; on focus or with a value `inset 0 0 0 2px var(--accent)`; on error `inset 0 0 0 2px var(--miss)`. The ring transitions over 200ms.
  - **"€" prefix:** 20px/700, `--muted`.
  - **Input:**
    - `inputmode="numeric" enterkeyhint="go" autocomplete="off" aria-label="Your price guess in euros" aria-describedby=<helper id>`, placeholder "Your guess".
    - 20px/700, tabular.
    - **Live formatting:** strip non-digits and leading zeros, cap at 9 digits, show `toLocaleString('en-US')` ("450,000"), keep the caret at the end.
  - **Guess button:** `type="submit"`, 48px tall, padding 0 22px, radius 999, background `--accent`, text `--on-accent`, 16px/800.
    - `disabled` while the field is empty (background `--raised`, text `--dim`).
    - Pressed: `scale(.95)`.
- **Helper line** below (13px, centred, min-height 18px, `aria-live="polite"`), one of:
  - default: "Within 10% wins · ↑ higher · ↓ lower · ↑↑ = 30%+ off" (`--muted`)
  - last try (5 guesses made): "Last try — make it count" (`--accent`, 800)
  - error: an alert icon (14px) plus the message (`--miss`, 700). Errors clear as soon as the player types.
- **Validation on submit** (none of these use up a try):
  - empty: the button is disabled, so nothing happens
  - below €10,000: "Enter the full price, e.g. 450,000" + shake
  - same value as an earlier guess: "You already tried €650,000" + shake
- **After a valid wrong guess:** clear the field and keep focus in it, so the mobile keyboard stays up for the next guess. Jump the view back to the newest photo. If the photo is scrolled out of view, scroll it into view smoothly (8px offset).
- **After the game ends:** blur the input (the keyboard closes), and the form is replaced by the result card.

## 7. Result card (after the game)

A `<section aria-live="polite">`: background `--surface`, radius 22, inner 1px ring `--line`, padding `18px 18px 14px`, centred column.

1. **Title**, Fraunces 31px/700:
   - "Good job!" in `--ok`
   - "Right on the money!" in `--accent` (exact price)
   - "You suck!" in `--miss` (loss)
2. "ASKING PRICE" label.
3. **Price** "€800,000", 38px/800, tabular. It counts up when the game ends live (spec/04 §5).
4. **Summary line**, 15px `--muted`:
   - win: "You were 3% off · solved on try 4"
   - exact: "The exact price, on try 1. Unreal."
   - loss: "Closest guess €690,000 · 14% off"
   - Percentages are rounded the same way the app rounds them today.
5. **Share button**, full width, 56px, radius 999, background `--accent`, a 20px share icon + "Share result".
   - When copied: background `--ok`, text `--on-ok`, a check icon + "Copied!" for 2.5s, then back.
6. **Row**, space-between, 14px:
   - "View listing ↗": a link to the listing, 44px tall, accent, 800
   - "Next casa **21:59:58**"

The guesses stay visible in the circles above the card, which fixes brief §9.

## 8. Clues panel (collapsible)

A `<section>`: radius 20, background `--surface`, inner 1px ring `--line`, `overflow: hidden`.

**Bar:** a full-width `<button>`, 56px tall, padding `0 16px 0 14px`, gap 10px, with `aria-expanded` and `aria-controls`. It contains:
- the magnifying glass (22px, accent)
- "Clues" (Fraunces 19px/650) and "{revealed} of 6" (13px/700 `--muted`)
- six 8px dots, right-aligned with 5px gaps: `--accent` if unlocked, `--lock-ring` if not
- a chevron (20px), rotated 180° when open

**Panel:** CSS grid with `grid-template-rows: 0fr` → `1fr` when open; the inner wrapper has `min-height: 0; overflow: hidden`. Collapsed by default every visit.

**Grid inside:** 2 columns, 8px gap, padding `0 10px 10px`. There are always **6 tiles, each exactly 78px tall**, so the panel never changes height when a clue unlocks.

- **Unlocked tile:** a `<button>` with background `--raised` and radius 14, padding `9px 11px`.
  - Top line (11px/800, `--accent`, letter-spacing .08em, gap 5px): the 14px magnifying glass (no glint), "CLUE 1", and "NEW" right-aligned on the newest clue during play.
  - Text: 14px/600, line-height 1.3, **clamped to 2 lines**, with the full text in a `title` attribute.
  - The tile showing the current photo gets an `inset 0 0 0 2px var(--accent)` ring.
  - Tapping it selects that try's photo and hint, and scrolls the photo into view if needed.
- **Locked tile:** **closed shutters**.
  - Two leaves (flex 1 each), each `repeating-linear-gradient(180deg, rgba(255,255,255,.08) 0 2px, transparent 2px 8px, rgba(0,0,0,.28) 8px 10px), var(--shutter)`.
  - A 1px dark seam where the leaves meet.
  - A centred pill (`rgba(10,10,10,.6)`, white 12px/800) with a lock icon and "Clue 5".
  - The tile is `role="img"` with `aria-label="Clue 5, locked"` and isn't focusable.
- **The shutter opening** is the signature animation (spec/04 §3.3).
- Unlocked tiles in a collapsed panel are only tabbable while the panel is open.

## 9. Map

- 180px tall, radius 20, `overflow: hidden`. Attribution caption below: "© OpenStreetMap contributors", 12px `--dim`, right-aligned. Keep Leaflet's own attribution control if the licence setup needs it.
- **Dark mode:** apply `filter: var(--map-filter)` to `.leaflet-tile-pane` **only**, not to markers, popups or controls.
- **Marker:** replace the default blue pin with a `L.divIcon`: a 28×38 teardrop in `--accent` with a 10px `--bg` dot and a soft shadow. It follows the country and theme. Anchor it at the tip.
- **Wheel zoom:**
  - `scrollWheelZoom: false` until the map is clicked or focused; disable it again on `mouseout` or `blur`.
  - Keep touch pinch and drag as today; one-finger drag can stay as it is now.
- **Zoom controls:** restyle them as 36px buttons with background `--surface`, colour `--text` and radius 10, or hide them. The owner is fine either way; default is restyle.
- Keep the map below the clues panel, at z-index ≤ 1000.

## 10. Ads

- **In-content slot:** a centred column with the label "ADVERTISEMENT" (11px/700, +0.14em, `--dim`) above a reserved 300×250 box (radius 14, background `--raised` while empty).
- **Anchor slot:** a fixed bottom bar, full-bleed, `height: calc(66px + env(safe-area-inset-bottom))`, background `--anchor-bg`, a 1px top line `--line`, with a centred 320×50 box.
- **`ADS_ENABLED` flag** (default false until real tags exist):
  - When false, don't render either slot, and remove the bottom padding reserved for the anchor.
  - When true but a slot doesn't fill, collapse it (`display: none`) after the ad script reports no fill. Never leave an empty grey box in production.
- The 300×250 placeholder visuals in the screenshots are for layout only.

## 11. Footer

"A new casa every day at 10:00 · bonus link", 14px `--muted`, centred, padding `4px 0 18px`. The link is accented. If the house has no bonus link, leave out the "· bonus link" part.

## 12. "No casa today"

Shown when no house is scheduled for the date. It replaces the whole game column; the header stays. Matches `17-no-casa-today`.

A card (background `--surface`, radius 24, padding `30px 22px 26px`, centred) containing:
1. A closed-shutters graphic, 150×104, radius 12, with a 6px `--raised` frame
2. "No casa today" (Fraunces 28)
3. "The agent is on siesta. A fresh casa goes up for sale at 10:00." (16px `--muted`)
4. The countdown (38px/800, tabular)
5. "Play yesterday's casa" (a 48px pill, background `--raised`) that links to `?day=<yesterday>`, only if yesterday had a house

## 13. Overlays

### 13.1 Photo zoom

`role="dialog" aria-modal="true" aria-label="Photo 4 of 6"`, `position: fixed; inset: 0; z-index: 1220`.

- **Backdrop:** `rgba(0,0,0,.95)`; clicking it closes the zoom.
- **Close button:** top-right, 44px, background `rgba(255,255,255,.14)`, offset 12px plus the safe-area inset. It gets focus on open.
- **Stage:** full width, max 900px, 4:3, max-height 78vh. The image uses `object-fit: contain`.
- **Clue pill:** the same component as on the page, also sitting above the photo (`top: -28px`) but at `left: 12px` with no overhang (the photo is full width), and without the `--bg` ring (the backdrop is black). Anchor it to the **rendered image box**, not the letterboxed stage (see spec/06 C4).
- **After the game:** prev/next buttons, swipe (>50px horizontal), and ←/→ keys.
- **Footer:** six dots (8px; the selected one is a 22×8 pill in white; unlocked at 45% white; locked at 16% white) and a caption:
  - during play: "Photo 4 of 6 · more unlock with each miss"
  - after the game: "Photo 2 of 6 · swipe or use the arrows"
- **Closing:** Escape, the close button, or the backdrop. Focus returns to the element that opened it.
- **Autoplay:** the carousel autoplay pauses while the zoom is open.

### 13.2 Bottom sheets (help, verdict, copy fallback)

- **Scrim:** `position: fixed; inset: 0; z-index: 1200`, background `--scrim`. Clicking it closes the sheet. For the verdict sheet that counts as "skip": the text is copied without a verdict, as today.
- **Sheet:** `position: fixed; bottom: 0`, centred, max-width 440, `z-index: 1210`, background `--surface`, radius `26px 26px 0 0`, padding `10px 20px calc(22px + safe-area)`, gap 14px.
  - A 40×5 grab handle at the top. Dragging it down more than 90px, or flicking faster than 0.6px/ms, dismisses the sheet.
  - `role="dialog" aria-modal="true" aria-labelledby=<title>`.
  - Tab focus is trapped inside; the first button is focused on open; Escape closes; focus returns to the element that opened it. Lock body scroll while open.

**How to play** (`09-how-to-play`): the title, then five rows. Each row is a 40px badge circle (background `--raised`, accent glyph) plus 16px text:

| Badge | Text |
|---|---|
| € | Guess the asking price of today's casa. |
| 6 | You get 6 tries. Land within ±10% to win. |
| ↑↓ | ↑ go higher, ↓ go lower. Two arrows: you're more than 30% off. |
| +1 | Every miss opens one more photo and clue. |
| 10 | A new casa goes up every day at 10:00. |

Below them, a primary button "Let's play" (56px, accent).

**Price verdict** (`14-price-verdict`), opened by Share on houses with the verdict question when the player hasn't voted yet:
1. **Head row:** a 92×69 thumbnail of photo 1 (radius 12) + "ASKING PRICE" / **€800,000** (28px/800) / the place (13px `--muted`).
2. "Steal, fair or rip-off?" (Fraunces 25) + "Your verdict goes into your share, hidden behind a spoiler." (14px `--muted`).
3. **Three equal tiles** (grid of 3, 8px gap), each 96px tall, radius 18, background `--raised`, holding a 28px line icon + a label (15px/800):
   - tag icon / **Steal**
   - balance scale / **Fair**
   - warning triangle / **Rip-off**
   - The labels never wrap: they fit at 320px width.
4. A text button "Skip and copy result" (44px, `--muted`, underlined).

Choosing a verdict saves it (existing logic), copies the text, and runs the choreography in spec/04 §8.

**Copy fallback:** "Copy your result" + "Your browser blocked automatic copying. Select the text below and copy it." + a read-only textarea holding the share text, auto-selected + "Done".

### 13.3 Toast

`role="status"`, fixed top-centre (12px + safe-area inset), `z-index: 1300`. A pill with background `--text` and text `--bg`, 14px/800, a check icon + "Result copied — paste it anywhere". It shows for 2.5s.

## 14. Accessibility summary

- Every interactive element is a real `<button>`, `<a>` or `<input>`, with a target ≥ 44×44.
- Focus ring: `outline: 2px solid var(--accent); outline-offset: 2px`, shown with `:focus-visible` only.
- Colour is never the only signal: wrong circles carry arrows, the correct one a check, locked ones dashed rings and a lock icon.
- Live regions: the helper line (errors), the result card, and the toast (`role="status"`).
- `lang="en"` on the page. The country name and the word for "house" can stay in the page language.
- Reduced motion: see spec/04 §10.
- Contrast: see spec/02.
