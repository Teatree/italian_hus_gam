# 08 · Copy

Use these strings verbatim. Typographic apostrophes (’) and the em dash (—) are intended. If the codebase has a strings file, add them there.

## Page and meta

| Where | Text |
|---|---|
| `<title>` | Guess My Casa |
| `og:title`, `twitter:title` | Guess My Casa |
| `meta description` / `og:description` | **Keep the existing description** (the "Italian 🥐 house" joke). Only replace the old game name if it appears in it. |
| Visible title | Guess My Casa |

## Header and meta row

| Element | Text |
|---|---|
| Theme toggle `aria-label` | Switch to light mode / Switch to dark mode |
| Help button `aria-label` | How to play |
| Chip | `{word} Nº {number} · {countryName}` (e.g. "Casa Nº 153 · Italia", "Maison Nº 153 · France"); without a number: "Casa · Italia" |
| Chip `aria-label` (when it's a link) | Bonus link |
| Countdown | New casa in **HH:MM:SS** (≤360px: only **HH:MM:SS**) |
| Countdown on a past-day link | `{Weekday short} {day} {Month short}`, e.g. "Sat 31 Oct" |

## Photo

| Element | Text |
|---|---|
| Image `alt` | Listing photo {n} of 6 |
| Clue pill | {clue text} (no label; magnifier icon is decorative) |
| Clue pill `aria-label` | Clue {n} of 6: {clue text} |
| Zoom button `aria-label` | Enlarge photo |
| Prev / next `aria-label` | Previous photo / Next photo |
| Review chip | Back to try {n} → |

## Tries

| State | Visible | `aria-label` |
|---|---|---|
| now | {n} / "now" | Try {n}, current |
| wrong | arrow / "300k" | Try {n}: €300,000, far too low (or "too low", "too high", "far too high") |
| right | ✓ / "780k" | Try {n}: €780,000, within 10% |
| locked | {n} / "–" | Try {n}, locked |
| unused | {n} / "–" | Try {n}, unused |
| Group `aria-label` | | Your six tries |

## Guess form

| Element | Text |
|---|---|
| Placeholder | Your guess |
| Input `aria-label` | Your price guess in euros |
| Button | Guess |
| Helper (default) | Within 10% wins · ↑ higher · ↓ lower · ↑↑ = 30%+ off |
| Helper (last try) | Last try — make it count |
| Error: too small | Enter the full price, e.g. 450,000 |
| Error: repeated | You already tried €{amount} |
| Screen-reader announcement after a wrong guess | €{amount} is {far too low / too low / too high / far too high}. Try {next} of 6. |

## Result card

| Element | Win | Exact | Loss |
|---|---|---|---|
| Title | Good job! | Right on the money! | You suck! |
| Label | ASKING PRICE | ASKING PRICE | ASKING PRICE |
| Line | You were {p}% off · solved on try {n} | The exact price, on try {n}. Unreal. | Closest guess €{amount} · {p}% off |
| Share button | Share result → (copied) Copied! | same | same |
| Link | View listing ↗ | same | same |
| Countdown | Next casa **HH:MM:SS** | same | same |

## Clues panel

| Element | Text |
|---|---|
| Bar | Clues · {revealed} of 6 |
| Tile label | 🔍 CLUE {n} (magnifier icon + text; + "NEW" on the newest during play) |
| Locked tile | 🔒 Clue {n} (`aria-label`: "Clue {n}, locked") |

## Sheets

**How to play.** Title: "How to play". Rows:
1. **€** Guess the asking price of today’s casa.
2. **6** You get 6 tries. Land within ±10% to win.
3. **↑↓** ↑ go higher, ↓ go lower. Two arrows: you’re more than 30% off.
4. **+1** Every miss opens one more photo and clue.
5. **10** A new casa goes up every day at 10:00.

Button: "Let’s play".

**Price verdict:**
- "ASKING PRICE" · €{price} · {place from hint 1, or the house config if it has a place field}
- Title: "Steal, fair or rip-off?"
- Sub: "Your verdict goes into your share, hidden behind a spoiler."
- Tiles: "Steal" · "Fair" · "Rip-off"
- Link: "Skip and copy result"

**Copy fallback:**
- Title: "Copy your result"
- Sub: "Your browser blocked automatic copying. Select the text below and copy it."
- Button: "Done"

## Toast

`✓ Result copied — paste it anywhere`

## Past-day banner and no-casa screen

| Element | Text |
|---|---|
| Banner | Casa from {Sat 31 Oct} |
| Banner button | Today’s casa → |
| No casa: title | No casa today |
| No casa: body | The agent is on siesta. A fresh casa goes up for sale at 10:00. |
| No casa: button | Play yesterday’s casa |

## Footer and ads

- Footer: "A new casa every day at 10:00 · bonus link"
- Ad label: "ADVERTISEMENT"

## Share text (only the first line changes)

Keep the app's existing builder and change only the game name on line 1. The examples below are from the brief, updated:

```text
Guess My Casa 🇮🇪
🇮🇪 🟥 🟥 🟩 ⬜ ⬜ ⬜
🎯 I was 3% off
🧾 My verdict: ||Fair price 🤝||
<site>/?day=01_11_26
```

```text
Guess My Casa 🇮🇪
🇮🇪 🟩 ⬜ ⬜ ⬜ ⬜ ⬜
🎯 RIGHT ON THE MONEY! (0% off)
🧾 My verdict: ||RIP-OFF 🚨||
<site>/?day=01_11_26
```

```text
Guess My Casa 🇮🇪
🇮🇪 🟥 🟥 🟥 🟥 🟥 🟥
Look how much I suck!
<site>/?day=01_11_26
```

- The flag is whatever the existing logic produces (the 🇮🇪 default is an intentional joke; disguised houses use theirs).
- Verdict labels inside the spoiler stay exactly as the app has them today.
- **Never** add the price or any euro amount.
