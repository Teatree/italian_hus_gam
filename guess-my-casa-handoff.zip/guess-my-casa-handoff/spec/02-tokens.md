# 02 · Design tokens

`spec/tokens.css` is the **single source of truth**. Put it in the app unchanged, apart from the font URLs. Components must use the variables, never raw hex values or Tailwind palette colours. Wire Tailwind to the variables:

```js
// tailwind.config.js (sketch)
theme: { extend: {
  colors: { bg:'var(--bg)', surface:'var(--surface)', raised:'var(--raised)', line:'var(--line)',
            text:'var(--text)', muted:'var(--muted)', dim:'var(--dim)', accent:'var(--accent)',
            'on-accent':'var(--on-accent)', miss:'var(--miss)', 'miss-bg':'var(--miss-bg)',
            ok:'var(--ok)', 'on-ok':'var(--on-ok)', 'lock-ring':'var(--lock-ring)' },
  fontFamily: { display:'var(--font-display)', ui:'var(--font-ui)' },
  borderRadius: { photo:'var(--radius-photo)', card:'var(--radius-card)', tile:'var(--radius-tile)', sheet:'var(--radius-sheet)' },
  transitionTimingFunction: { out:'var(--ease-out)', in:'var(--ease-in)', 'in-out':'var(--ease-in-out)', spring:'var(--ease-spring)', sheet:'var(--ease-sheet)' },
  zIndex: { sticky:'1050', anchor:'1100', fx:'1150', scrim:'1200', sheet:'1210', zoom:'1220', toast:'1300' },
}}
```

Attributes on `<html>` select the token set:

| Attribute | Values | Default |
|---|---|---|
| `data-theme` | `dark` · `light` | `dark` (always, unless the player chose light) |
| `data-country` | `it` · `es` · `pt` · `fr` · `gr` | `it` |
| `data-season` | `halloween` (more later) | absent |

## Colour roles

| Token | Dark | Light | Used for |
|---|---|---|---|
| `--bg` | `#121A26` | `#FAF3E6` | Page background, the gap ring around a selected circle |
| `--surface` | `#1B2433` | `#FFFDF8` | Field, result card, clues panel, chip, sheets |
| `--raised` | `#232E40` | `#F0E4CF` | Icon buttons, clue tiles, verdict tiles, ad slots, disabled button |
| `--line` | `#2E3A50` | `#E3D3B9` | Hairlines, field ring at rest, sheet handle |
| `--text` | `#F1E9DC` | `#3A2A20` | Primary text, selected-circle ring, toast background |
| `--muted` | `#A9B1BE` | `#6E5A49` | Secondary text, helper line |
| `--dim` | `#8B95A6` | `#7A6553` | Locked numbers, captions, ad labels |
| `--stripe` | `#E9DFCC` | `#FFFDF8` | The light awning stripe |
| `--accent` | per country (dark) | per country (light) | Awning, "now" circle, Guess and Share buttons, links, clue numbers, NEW tags |
| `--on-accent` | `#1A120C` | `#FFFDF8` | Text on accent |
| `--miss` / `--miss-bg` | `#F07083` / `rgba(240,112,131,.14)` | `#A8243A` / `#F7DCE0` | Wrong-guess circles, errors, the "You suck!" title, rain |
| `--ok` / `--on-ok` | `#6FD39A` / `#0E2A1A` | `#2E7D4F` / `#FFFFFF` | Correct circle, the "Good job!" title, the "Copied!" button |
| `--lock-ring` | `#4A5770` | `#C2AE90` | Dashed ring on locked circles, unlit clue dots |
| `--shutter` | per country | same | Shutter slats |
| `--overlay-ink` | `rgba(8,8,8,.64)` | same | Photo buttons (always dark over photos) |
| `--scrim` | `rgba(0,0,0,.55)` | `rgba(30,20,12,.45)` | Behind sheets |
| `--map-filter` | `invert(.92) hue-rotate(180deg) saturate(.55) brightness(.92)` | `none` | Leaflet **tile pane only** |

**Per country** (`--accent-d` is the dark-mode accent, `--accent-l` the light-mode accent):

| Country | `data-country` | Accent dark | Accent light | Shutter | Name / word for house |
|---|---|---|---|---|---|
| Italy | `it` | `#E8875A` terracotta | `#B44E28` | `#3F6B4E` green | Italia / Casa |
| Spain | `es` | `#EE8A5E` | `#A8321C` | `#7C5130` wood | España / Casa |
| Portugal | `pt` | `#78A6E6` azulejo | `#1F5AA6` | `#2D5C8A` | Portugal / Casa |
| France | `fr` | `#AC9BE0` lavender | `#62509E` | `#5F7F86` sage | France / Maison |
| Greece | `gr` | `#6AAEE0` Aegean | `#17649F` | `#1F5FA0` | Hellas / Spíti |
| Finland (existing disguise icon) | `fi` | `#86B4EC` | `#1D4F91` | `#7A5A3E` wood | Suomi / Talo |

To add a country: add one `[data-country="xx"]` line to `tokens.css` (dark accent ≥ 4.5:1 on `#121A26`, light accent ≥ 4.5:1 on `#FAF3E6` and with `#FFFDF8` text on it), plus a `{ name, word, flagColors }` entry in the country map (spec/07 §2).

## Contrast (all verified with WCAG 2.x)

| Pair | Dark | Light |
|---|---|---|
| text / bg | 14.5 | 12.4 |
| muted / bg | 8.1 | 5.9 |
| dim / bg | 5.8 | 5.0 |
| miss / bg | 6.1 | 6.4 |
| ok / bg | 9.5 | 4.6 |
| on-ok / ok | 8.4 | 5.1 |
| accent / bg (worst country) | 6.7 (it) | 4.7 (it) |
| on-accent / accent (worst) | 7.1 (it) | 5.1 (it) |

`--dim` on `--raised` in light mode is 4.4. It is only used for the **disabled** Guess button label, which WCAG exempts. Don't use it for anything else.

## Typography

| Role | Font | Size / weight | Notes |
|---|---|---|---|
| Title | Fraunces | 29px / 650, opsz 72, -0.01em | 24px at ≤360px viewport width |
| Section titles (Clues, sheet titles) | Fraunces | 19px (Clues), 25px (sheets) / 650 | |
| Result title | Fraunces | 31px / 700 | |
| Price on the result card | Manrope | 38px / 800, tabular, -0.02em | |
| Field value | Manrope | 20px / 700, tabular | |
| Body | Manrope | 15–16px / 400–600 | |
| Clue pill text | Manrope | 14px / 700, line-height 1.25, `--text` on `--surface` | Max 2 lines |
| Try circle content | Manrope | 16px / 800 (18px for "now") | |
| Try label | Manrope | 13px / 700 | |
| Labels (ASKING PRICE, ADVERTISEMENT) | Manrope | 11px / 800, +0.14em, uppercase | |
| Helper line | Manrope | 13px | |

Self-host `fraunces.woff2` (variable: opsz and wght) and `manrope.woff2` + `manrope-ext.woff2` (variable: wght) from `reference/prototype/fonts/`. Use `font-display: swap` and preload the Latin files.

## Geometry

| Token | Value | Notes |
|---|---|---|
| `--column-max` | 440px | Single column on every screen |
| `--gutter` | 16px | Page side padding |
| `--gap` | 16px | Between main blocks |
| `--radius-photo` / card / tile / sheet | 20 / 22 / 14 / 26px | |
| `--tap` | 44px | Minimum touch target, no exceptions |
| `--control-h` / `--control-inner-h` | 60 / 48px | Price pill / Guess button |
| `--circle` | `clamp(40px, 11.8vw, 46px)` | Try circles |
| Awning | 26px stripes (52px repeat), 24px tall + 13px scallops | Pure CSS, full-bleed at any width |
| `--anchor-h` | 66px | 320×50 ad + padding; plus `env(safe-area-inset-bottom)` |

## Layers

| Token | z-index | What |
|---|---|---|
| Leaflet | ≤ 1000 | Map panes and controls |
| `--z-sticky` | 1050 | Past-day banner |
| `--z-anchor` | 1100 | Sticky anchor ad |
| `--z-fx` | 1150 | Confetti canvas, loss rain (pointer-events: none) |
| `--z-scrim` / `--z-sheet` | 1200 / 1210 | Sheets |
| `--z-zoom` | 1220 | Photo zoom |
| `--z-toast` | 1300 | Toast |

## Motion tokens

| Token | Value | Use |
|---|---|---|
| `--ease-out` | `cubic-bezier(0.22, 1, 0.36, 1)` | Anything entering |
| `--ease-in` | `cubic-bezier(0.55, 0, 1, 0.45)` | Anything leaving |
| `--ease-in-out` | `cubic-bezier(0.65, 0, 0.35, 1)` | Crossfades, colour changes, shutters |
| `--ease-spring` | `cubic-bezier(0.34, 1.56, 0.64, 1)` | Small pops (arrows, dots, the chosen verdict, stamps) |
| `--ease-sheet` | `cubic-bezier(0.32, 0.72, 0, 1)` | Bottom sheets |
| `--dur-xs` … `--dur-xl` | 120 / 200 / 320 / 600 / 900ms | |
