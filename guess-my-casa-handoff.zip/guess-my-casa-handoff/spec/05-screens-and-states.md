# 05 · Screens and states

Every screenshot was rendered from `reference/prototype/` with Chromium. Phones are **390×844 at DPR 2** (full-page captures are taller than the viewport), the small phone is 320×640, and desktop is 1280×900. The prototype URL is listed for each one, so you can reproduce it (all with `&frozen=1&fx=0`).

The mock house is the brief's 1 November house: **€800,000**, La Serra-Tellaro, Lerici. Only three distinct photos were available for the mock, so photos repeat. The map is a static image with Leaflet's default pin baked in. The real map uses the accent-coloured `divIcon` pin (spec/03 §9).

"Old #" refers to the owner's original screenshot numbers in `context/ORIGINAL-DESIGN-BRIEF.md`.

## Playing

| File | State | Prototype | Old # | Check |
|---|---|---|---|---|
| `01-first-visit.mobile.jpg` | Try 1 is `now`, no guesses, clue 1 on the photo, Clues "1 of 6" collapsed, Guess disabled | `screen=start` | 01 | The clue pill sits above the photo, overlaps its top edge and hangs past its left edge; the awning scallops; the input is above the fold |
| `02-typing-a-guess.mobile.jpg` | "450,000" typed, accent ring, Guess enabled | `screen=typing` | 02 | Live formatting with a comma |
| `03-invalid-input.mobile.jpg` | "45" + error "Enter the full price, e.g. 450,000", miss ring | `screen=invalid` | — | New feedback (brief §9) |
| `04-after-3-wrong-guesses.mobile.jpg` | Circles ↑↑ 300k, ↓↓ 1.5M, ↑ 650k, 4 is `now` with glow, photo 4 + clue 4 | `screen=mid` | 03 | The guess list is gone, and so is the input drift |
| `05-clues-panel-open.mobile.jpg` | Same, with the Clues panel open: 4 tiles, the newest with an accent ring and NEW, 2 shutter tiles | `screen=clues` | — | Tiles are fixed at 78px; the shutters show slats, a seam and a lock pill |
| `06-reviewing-try-2.mobile.jpg` | Try 2 selected (white ring), photo 2 + clue 2, "Back to try 4 →" chip | `screen=review` | 05 | The chip sits bottom-left, the zoom button bottom-right |
| `07-last-try.mobile.jpg` | 5 wrong guesses (including ↓ 1M and ↑ 690k), 6 is `now`, helper "Last try — make it count" | `screen=last` | 04 | The breathing glow is only visible live |
| `08-photo-zoom.mobile.jpg` | Zoom during play: no arrows, dots (4 lit, #4 a pill), caption "more unlock with each miss" | `screen=zoom` | 06 | |
| `09-how-to-play.mobile.jpg` | How-to-play sheet over the scrim | `screen=help` | — | New |

## Results and sharing

| File | State | Prototype | Old # | Check |
|---|---|---|---|---|
| `10-win.mobile.jpg` | 4th guess (780k) correct: green check; 5 and 6 unused; result card "Good job!", €800,000, "You were 3% off · solved on try 4", Share; prev/next on the photo | `screen=win` | 08 | The guesses stay visible |
| `11-exact-price.mobile.jpg` | First guess exact; "Right on the money!" in accent | `screen=exact` | 11 | |
| `12-loss.mobile.jpg` | Six wrong guesses; "You suck!" in miss; "Closest guess €690,000 · 14% off" | `screen=loss` | 13 | |
| `13-end-carousel-zoomed.mobile.jpg` | Zoom after the game, photo 2, arrows, caption "swipe or use the arrows" | `screen=zoomEnd` | 15 | |
| `14-price-verdict.mobile.jpg` | Verdict sheet: thumbnail, €800,000, place, question, 3 equal tiles, skip | `screen=verdict` | 16 | "Rip-off" is on one line |
| `15-result-copied.mobile.jpg` | Toast at the top, Share button green "Copied!" | `screen=copied` | 19 | |

## Edge screens

| File | State | Prototype | Old # |
|---|---|---|---|
| `16-past-day-link.mobile.jpg` | Accent banner "Casa from Sat 31 Oct" + "Today's casa →", sticky; the meta row shows the date, no countdown | `screen=pastday` | 20/21 |
| `17-no-casa-today.mobile.jpg` | Closed shutters card, "No casa today", countdown, "Play yesterday's casa" | `screen=nopuzzle` | 22 |
| `50-small-phone-320-last-try.jpg` | 320px: title 24px, the "New casa in" label hidden, circles 40px, all on one line | `screen=last` at 320×640 | — |
| `51-desktop-mid.jpg` | 1280×900: centred 440px column, full-bleed awning and anchor bar | `screen=mid` | 03 desktop |
| `52-desktop-verdict.jpg` | Desktop sheet, max 440 wide, centred | `screen=verdict` | 16 desktop |
| `53-desktop-zoom.jpg` | Desktop zoom, stage max 900px | `screen=zoomEnd` | 15 desktop |

## Light mode

| File | Prototype |
|---|---|
| `20-light-first-visit.mobile.jpg` | `screen=start&mode=light` |
| `21-light-clues-open.mobile.jpg` | `screen=clues&mode=light` |
| `22-light-win.mobile.jpg` | `screen=win&mode=light` |
| `23-light-loss.mobile.jpg` | `screen=loss&mode=light` |
| `24-light-how-to-play.mobile.jpg` | `screen=help&mode=light` |
| `25-light-price-verdict.mobile.jpg` | `screen=verdict&mode=light` |
| `26-light-no-casa-today.mobile.jpg` | `screen=nopuzzle&mode=light` |
| `27-light-photo-zoom.mobile.jpg` | `screen=zoom&mode=light` |

## Countries and seasons

| File | What to notice |
|---|---|
| `30-country-spain-clues.mobile.jpg` | Spanish flag; wooden shutters; warm accent |
| `31-country-portugal-clues.mobile.jpg` | Azulejo-blue accent and awning; blue shutters |
| `32-country-france-clues.mobile.jpg` | "Maison Nº 153 · France"; lavender accent; sage shutters |
| `33-country-greece-clues.mobile.jpg` | "Spíti Nº 153 · Hellas"; Aegean blue |
| `34-country-greece-light-clues.mobile.jpg` | Greece in light mode |
| `35-country-spain-light-win.mobile.jpg` | Spain light win; Share in the deep red accent |
| `40-season-halloween-clues.mobile.jpg` | Purple night palette, orange accent, dark awning stripe, theme toggle hidden |
| `41-season-halloween-win.mobile.jpg` | Halloween win (lime "ok") |

In the real app the Halloween season also layers its existing fog, cobwebs, candle flicker, Creepster title, candy confetti and ghost rain on top (spec/07 §4). Those effects aren't in the prototype.

## Motion moments (stills with effects on)

| File | Moment |
|---|---|
| `60-moment-win-confetti.mobile.jpg` | About 650ms after a win: confetti from both sides, the card rising, the price counting |
| `61-moment-exact-burst.mobile.jpg` | Exact: side bursts + centre burst |
| `62-moment-loss-rain.mobile.jpg` | Thumbs-down rain + the stamped "You suck!" |
| `63-moment-shutter-opening.mobile.jpg` | A wrong guess with the panel open: the new tile mid-reveal, the arrow popping, the new "now" |

For full sequences, see `motion/` (filmstrips) and `videos/` (MP4s).

## Motion filmstrip index

| File | Sequence | Spec |
|---|---|---|
| `motion/01-wrong-guess.jpg` | The core loop | §3 |
| `motion/02-clues-panel-open.jpg` | Panel expand | §4 |
| `motion/03-review-earlier-try.jpg` | Selecting an earlier try | §2 |
| `motion/04-invalid-shake.jpg` | Error shake | §3.1 |
| `motion/05-win.jpg` | Win choreography | §5 |
| `motion/06-share-opens-verdict.jpg` | Sheet open | §7 |
| `motion/07-verdict-pick-and-copied.jpg` | Pick → close → toast → Copied | §7 |
| `motion/08-exact-price.jpg` | Exact | §5.1 |
| `motion/09-loss.jpg` | Loss | §5.2 |
| `motion/10-theme-toggle.jpg` | Theme cross-fade | §9 |
| `motion/11-help-sheet-open.jpg`, `12-help-sheet-close.jpg` | Sheet in/out | §7 |
| `motion/13-zoom-open.jpg`, `14-zoom-close.jpg` | FLIP zoom | §8 |
| `motion/15-carousel-next.jpg` | Carousel crossfade | §2 |
| `motion/16-zoom-next.jpg` | Next photo inside the zoom | §8 |

The frame timestamps are approximate (about ±60ms), because they were cut from screen recordings.
