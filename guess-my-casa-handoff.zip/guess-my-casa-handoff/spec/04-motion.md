# 04 · Motion

The owner cares most about this part. The game's personality comes from small, quick, layered animations. **Every timing here is implemented in `reference/prototype/styles.css` and `app.js`.** Copy the keyframes and values from there. The `motion/*.jpg` filmstrips show each sequence frame by frame, with ms timestamps (`+0 ms` is the moment of the tap, give or take about 50ms).

**Principles:**
1. **Things that enter** ease out (`--ease-out`); **things that leave** ease in, faster (`--ease-in`, about 2/3 of the enter time). **State and colour changes** use `--ease-in-out`.
2. **Small things pop** with a slight overshoot (`--ease-spring`). Big surfaces never overshoot.
3. **Choreograph, don't fire everything at once.** Each event below has an order, and the delays are part of the spec.
4. **Nothing animates on first paint or on restore.** Add a `no-anim` class to the root for the first two animation frames (`transition: none; animation: none` on everything), then remove it. A finished game loaded from storage appears in its final state with **no confetti, no count-up, no shutter cascade**. Celebrations play only when the game ends live, in this session.
5. **Never animate layout properties** (width, height, top). Use transforms and opacity. The one exception is the Clues panel's `grid-template-rows: 0fr → 1fr`, which is cheap.
6. **Interruptions:** any new event cancels or overrides the running one cleanly. If the player taps try 2 while try 3's photo is crossfading, start the new crossfade from the current state. Never queue animations up.

## 1. Press feedback (everything tappable)

| Element | Pressed | Release |
|---|---|---|
| Icon buttons, photo buttons | `scale(.92)` | back over 120ms `--ease-out` |
| Guess button, chip, sheet buttons, pills | `scale(.95–.97)` | back over 120ms |
| Try circle (enabled) | circle `scale(.93)` | back over 200ms |
| Verdict tile | `scale(.96)` | spring to the chosen state (§8) |

## 2. Photo crossfade + clue swap (selecting another try, reviewing, carousel)

Filmstrips: `motion/03-review-earlier-try.jpg`, `motion/15-carousel-next.jpg`.

- **Photo:**
  1. Load the incoming image into the back `<img>` and wait for `img.decode()` so it never flashes half-loaded.
  2. The incoming image starts at `opacity 0; scale(1.02)`.
  3. Fade it to `opacity 1` over **400ms** (during play) or **700ms** (the end-of-game carousel), `--ease-in-out`.
  4. At the same time, settle its scale to 1 over 1200ms `--ease-out` (a slow, subtle zoom-in feel).
  5. The outgoing image fades to 0 over the same duration.
- **Clue pill:** the pill itself stays put. Only its text changes: the old text goes to `opacity 0; translateY(-4px)` over 140ms `--ease-in`, then the text is swapped and fades back in over 140ms. The pill width animates naturally with the text (no explicit width animation).
- **Selected ring** on the circle: an instant box-shadow change (it reads as a snap, which is intended).
- **"Back to try N →" chip:** fades in and slides from `translateX(-12px)` (200ms opacity, 320ms transform, `--ease-out`). It leaves the same way.
- **The tile ring in the Clues panel** moves with the selection (200ms box-shadow).

## 3. Wrong guess (the core loop)

Filmstrip: `motion/01-wrong-guess.jpg`. Video: `videos/guess-flow.mp4`.

| t (ms) | What happens | Spec |
|---|---|---|
| 0 | Submit. Clear the field, keep the focus (keyboard stays up). | |
| 0 | The **guessed circle** changes `now → wrong`: fill, border and text colour transition over 450ms `--ease-in-out`; the number fades out over 150ms. | `.try__circle` transition |
| 180 | The **arrow pops in**: `scale(.4) opacity 0 → scale(1) opacity 1`, 420ms `--ease-spring`. | `@keyframes pop`, delay 180ms |
| 260 | The **value label** slides up: `translateY(6px) opacity 0 → 0`, 360ms `--ease-out`. | `@keyframes labelUp`, delay 260ms |
| 250 | The **next circle** becomes `now`: colour transitions over 450ms, then a bounce `scale .82 → 1.08 → 1` over 520ms `--ease-spring`. The glow comes in with the colour. | `@keyframes nowIn`, delay 250ms |
| 0 | The **photo crossfades** to the new photo (§2, 400ms). | |
| 140 | The **new clue** arrives: the clue pill swaps its text and **slides in from the left** (`translateX(-14px) opacity 0 → none`, 520ms `--ease-out`). At 360ms the **magnifying glass wiggles** like it's searching: `rotate 0 → -16° (scale 1.08) → 11° → -5° → 0`, 720ms `--ease-in-out`, pivoting on the lens centre. This is the "new clue" cue. | `@keyframes tagIn`, `glassWiggle` |
| 0 | **Clue dot** n+1 lights: background to `--accent` over 300ms, plus a pop `scale .4 → 1.5 → 1` over 420ms spring. | `@keyframes dotPop` |
| 0 | If the Clues panel is **open**, tile n+1's **shutters swing open** (§3.3). If it's closed, the tile is switched to open with no animation, so it's ready the next time the panel opens. | |
| 0 | If the photo is scrolled out of view, smooth-scroll it into view (8px top offset). | |

### 3.1 Invalid input

Filmstrip `motion/04-invalid-shake.jpg`.
- The field ring turns `--miss` (200ms).
- The field shakes horizontally: `0 → -7 → 6 → -4 → 2 → 0px` over 340ms `--ease-out` (`@keyframes shake`).
- The helper text swaps to the error with a 200ms fade.
- No try is used up. The error clears on the next keystroke, without animation.

### 3.2 Typing

- The ring goes from `--line` to `--accent` (200ms) when the field gets a value or focus.
- The Guess button goes from disabled (`--raised` / `--dim`) to enabled (`--accent` / `--on-accent`) with a 200ms colour transition.
- Live formatting happens without animation.

### 3.3 Shutters opening (signature animation)

Filmstrips: `motion/01-wrong-guess.jpg` (tiles at the bottom), `motion/05-win.jpg`, `motion/09-loss.jpg`. Still: `screenshots/63-moment-shutter-opening.mobile.jpg`.

- **Setup:** the shutter container has `perspective: 520px`. The left leaf has `transform-origin: 0 50%`, the right leaf `100% 50%`, both `backface-visibility: hidden`.
- **The sequence:**
  1. The lock pill fades out over 150ms `--ease-in`.
  2. The leaves swing outward like real window shutters: left `rotateY(0 → -112deg)`, right `rotateY(0 → 112deg)`, 640ms `--ease-in-out`.
  3. The leaves fade to 0 over 200ms, starting at 480ms, so nothing lingers edge-on.
  4. The tile content fades in from 260ms over 300ms `--ease-out`.
  5. The "NEW" tag fades in at 500ms.
- **At game end:** all remaining locked tiles open **one after another, 450ms apart** (matching today's "remaining hints appear 450ms apart"), and their dots light with the same stagger. Only if the panel is open; if it's closed, they open instantly and silently.

### 3.4 Last try

- When try 6 becomes `now`, the helper turns accent: "Last try — make it count".
- The circle's glow breathes forever: `0 0 0 4px halo, 0 0 18px glow ↔ 0 0 0 7px halo, 0 0 30px glow`, 2.2s `--ease-in-out`, infinite, starting after the `nowIn` bounce (800ms delay). It's visible in `videos/guess-flow.mp4` and the prototype (`?screen=last`).

## 4. Clues panel open and close

Filmstrip: `motion/02-clues-panel-open.jpg`.

- The panel's `grid-template-rows` goes `0fr → 1fr` over 320ms `--ease-out`; collapsing uses the same values.
- The grid inside goes from `opacity 0, translateY(-6px)` to visible: 200ms opacity and 320ms transform, with a 60ms delay on open.
- The chevron rotates 180° over 320ms `--ease-out`.
- The page content below is pushed down smoothly by the panel animation (no jump).

## 5. Game end: win

Filmstrip: `motion/05-win.jpg`. Video: `videos/win-flow.mp4`. Stills: `screenshots/60-moment-win-confetti.mobile.jpg`.

| t (ms) | What happens |
|---|---|
| 0 | The winning circle goes `now → right`: green fill over 450ms; the **check pops** (pop keyframes, spring, 180ms delay); the value label turns `--ok` and slides up (260ms delay). The input blurs, so the keyboard closes. |
| 0 | **Confetti** (canvas-confetti, §6), two bursts from the left and right edges at 62% viewport height. |
| 0–180 | The **form leaves**: `opacity 1 → 0, translateY(0 → -6px)`, 180ms `--ease-in`; then it's removed. |
| 180 | The **result card rises**: `opacity 0, translateY(16px) → none`, 460ms `--ease-out`. |
| 300 | The **title stamps** in: `opacity 0, scale(1.35) → scale(1)`, 520ms `--ease-spring`. |
| 380 | The **price counts up** from €0 to the price over **900ms**, easeOutCubic, rounded to €1,000 steps and landing exactly on the price. It uses tabular figures so the width doesn't jitter. |
| 560 | The **Share button rises** (380ms `--ease-out`). |
| ~300 | After the card has entered, `scrollIntoView({block:'nearest', behavior:'smooth'})` so the Share button is on screen. |
| 0 → | The **remaining shutters open** in sequence, 450ms apart (§3.3), if the panel is open. |
| 2000 | The **unused circles** (tries after the winning one) fade from the locked style to the "unused" style over 600ms. This is today's "unused tries lighten after 2s". |
| 4000 | The **carousel autoplay** starts: next photo every 5s, 700ms crossfade (§2). The prev/next buttons faded in at game end (800ms). |

### 5.1 Exact price

Filmstrip `motion/08-exact-price.jpg`, still `screenshots/61-moment-exact-burst.mobile.jpg`.
- Same as a win, plus a **180-piece centre burst** from (50%, 42%) in all directions (§6).
- The title is "Right on the money!" in `--accent`.

### 5.2 Loss

Filmstrip `motion/09-loss.jpg`. Video `videos/loss-flow.mp4`. Still `screenshots/62-moment-loss-rain.mobile.jpg`.
- The sixth circle goes `now → wrong` (§3).
- **Thumbs-down rain:**
  - 12 waves, 4 icons per wave, one wave every 150ms (today's numbers). Each icon is an SVG thumbs-down (stroke `--miss`, 22–36px) starting at a random x, 48px above the viewport.
  - Each falls `translateY(0 → 100vh+80px)` over 1.5–2.4s with `cubic-bezier(.45,0,.9,.6)` (gravity), rotating from `r0 ∈ [-30°, 30°]` to `r1 ∈ [-60°, 60°]`.
  - Each is removed on `animationend`.
- The form leaves and the card rises as for a win. "You suck!" stamps in, then **wobbles** (`rotate 0 → -3° → 2.5° → -1.5° → 0`, 520ms, 640ms delay).
- No count-up difference: the price still counts up.
- The shutters cascade open.

## 6. Confetti settings (`canvas-confetti`)

Colours: the house country's flag colours + `--accent` + `--ok` (for Italy: `#009246 #F4F5F0 #CE2B37 <accent> <ok>`). Read the accent from computed style at fire time, so it follows the theme and country.

```js
const base = { particleCount: 70, spread: 40, startVelocity: 55, gravity: 1, decay: 0.92, ticks: 260,
               scalar: 1, colors, disableForReducedMotion: true, zIndex: 1150 };
confetti({ ...base, angle: 60,  origin: { x: 0, y: 0.62 } });   // from the left edge
confetti({ ...base, angle: 120, origin: { x: 1, y: 0.62 } });   // from the right edge
// exact price only:
confetti({ particleCount: 180, spread: 360, startVelocity: 32, gravity: 0.9, ticks: 280,
           origin: { x: 0.5, y: 0.42 }, colors, disableForReducedMotion: true, zIndex: 1150 });
```

The prototype draws its own canvas confetti with equivalent physics (`app.js → confetti()`). Use the library the app already ships. Seasons can override the colours and shapes (spec/07 §4).

## 7. Share → verdict sheet → copied

Filmstrips `motion/06-share-opens-verdict.jpg`, `motion/07-verdict-pick-and-copied.jpg`.

**Opening any sheet:**
- The scrim fades `0 → 1` over 200ms `--ease-out`.
- The sheet slides `translateY(100%) → 0` over **360ms `--ease-sheet`**.
- The first button gets focus (no scroll jump). Body scroll is locked.

**Closing a sheet:**
- The sheet slides back to `translateY(100%)` over **240ms `--ease-in`**; the scrim fades out over 200ms.
- Then `hidden`, and focus returns to where it was.

**Drag to dismiss:**
- While dragging the handle, the sheet follows the finger 1:1 (`translateY(dy)`, no transition, only downward).
- On release: if dy > 90px or the velocity is > 0.6px/ms, close (240ms). Otherwise spring back with the 360ms open curve.

**Choosing a verdict:**

| t (ms) | What happens |
|---|---|
| 0 | The chosen tile fills `--accent` with text `--on-accent` (200ms) and springs to `scale(1.06)` (300ms `--ease-spring`). The other two dim to `opacity .35` (300ms). |
| 500 | The sheet closes (240ms). Today's popup also closed at 500ms. |
| 740 | Copy to the clipboard. On success, the Share button turns `--ok` with "✓ Copied!" (250ms colour change; the check pops); the **toast** slides in from `translate(-50%,-160%)` to `0` over 260ms `--ease-out`. |
| 740 + 2500 | The toast leaves (200ms `--ease-in`); the button reverts to "Share result" (250ms). |

"Skip and copy result", a scrim tap, Escape or a drag-dismiss: the sheet closes, then the text is copied without a verdict (same as today).

## 8. Photo zoom (FLIP)

Filmstrips `motion/13-zoom-open.jpg`, `motion/14-zoom-close.jpg`, `motion/16-zoom-next.jpg`.

**Open:**
1. Measure the on-page photo's rect (`first`) and the zoom image's final rect (`last`).
2. Set the zoom image to `transform: translate(dx,dy) scale(sx,sy)` (origin 0 0), so it sits exactly over the page photo.
3. On the next frame, transition the transform to `none` over 320ms `--ease-out`.
4. At the same time, the backdrop fades from 0 to 95% black over 220ms. The close button, clue pill, dots and caption fade in over 200ms.

**Close:** the reverse. Transition the image back to the page photo's rect (320ms) while everything else fades out (200ms). Then hide.

**Next/prev inside the zoom** (after the game):
- The image fades and slides out (200ms `--ease-in`), the source swaps, and the new image fades in.
- The clue pill text swaps (§2), and the selected dot animates its width from 8 to 22px (300ms `--ease-out`).
- A swipe of more than 50px triggers it; ←/→ keys work too.

## 9. Theme toggle

Filmstrip `motion/10-theme-toggle.jpg`.

- On click, add `.theming` to `<html>` for 420ms. It sets `transition: background-color, color, border-color, box-shadow, fill, stroke 280ms --ease-in-out` on **every** element, so the whole page cross-fades together.
- Flip `data-theme`, save it to `localStorage`, and update `<meta name="theme-color">`.
- The sun/moon icons cross-rotate: the outgoing one goes to `rotate(-90deg) scale(.6) opacity 0`, the incoming one to `none`, over 320ms `--ease-out` (opacity 200ms).
- Optional: if `document.startViewTransition` exists, it may be used instead. Keep the fallback.

## 10. Reduced motion (`prefers-reduced-motion: reduce`)

Keep **colour and opacity changes** (they carry meaning). Drop **movement, bounce, particles and autoplay**:

| Effect | Reduced |
|---|---|
| Confetti, loss rain | Off (`disableForReducedMotion: true`; the rain doesn't spawn) |
| Count-up | The final price is shown immediately |
| Pops, bounces, stamps, wobbles, shakes, the breathing glow | Off: final state at once (shake → the error colour only) |
| Photo crossfade | Instant swap, or opacity only with no scale |
| Clue swap, clue pill entrance, magnifier wiggle | Instant text swap, no slide or wiggle |
| Shutters | No 3D rotation: the leaves fade out over 200ms |
| Sheets and toast | Opacity fade only, no slide |
| Zoom | No FLIP: fade in/out |
| Clues panel | Height change stays (it's spatial context), the grid slide is removed |
| Carousel autoplay | Off (manual navigation only) |
| Shutter cascade at game end | All open at once |
| Smooth scrolling | `auto` |

Today only some effects honour the setting (brief §9). After this change, all of them do.

## 11. Performance notes

- Animate only `transform` and `opacity` (and colours). Apply `will-change: transform` to the zoom image only during the FLIP.
- The confetti canvas is `pointer-events: none`, fixed, and covers the viewport. Remove it or clear it when done.
- Remove rain nodes on `animationend`.
- Clean up timers when the component unmounts (React effects).
- Don't run the countdown `setInterval` while the tab is hidden; recompute on `visibilitychange`.
