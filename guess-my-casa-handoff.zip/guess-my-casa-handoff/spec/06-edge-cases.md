# 06 · Edge cases

Handle every row. Tick each one off in `REDESIGN-NOTES.md`.

## Content (photos, hints, data)

| # | Case | Required behaviour |
|---|---|---|
| C1 | **Long hint** (e.g. 80+ characters) | The clue pill wraps to at most 2 lines with an ellipsis (`line-clamp: 2`, max-width 300px). It is anchored by its top (`top: -28px`), so a 2-line pill just overlaps the photo a little more, which is fine. The Clues tile clamps to 2 lines and has the full text in `title`. Nothing changes height. The full text is reachable in the panel. Test with "Detached stone farmhouse with olive grove, sea view terrace and separate guest annex". |
| C2 | **Very short or empty hint** | Short: the pill shrinks to fit (it never stretches). Empty: hide the whole pill (`hidden`), not just its text; the tile shows only "CLUE n". |
| C3 | **Watermarked photos** (most idealista photos) | The pill only covers a ~12px band at the top-left of the photo, so it no longer hides part of the photo. Don't add overlays in the middle of the photo. |
| C4 | **Non-4:3 photos** (portrait, panorama) | On the page: `object-fit: cover` in a 4:3 frame. In the zoom: `object-fit: contain`. **Anchor the zoom clue pill to the top-left of the rendered image box, not the letterboxed stage.** Compute it from the natural size, or wrap the image in an element sized to the contained box. |
| C5 | **Animated WebP photo** | It loops by itself. The crossfade still works (`decode()` resolves on the first frame). Don't pause it. |
| C6 | **Photo fails to load** | Keep the 4:3 frame with background `--raised`, show a 32px house outline icon in `--dim` in the centre, keep the clue pill, and don't break the crossfade (resolve on `error` as well as `decode`). Never show a broken-image icon. |
| C7 | **Slow network** | The next photo is preloaded when a wrong guess reveals it (`new Image().src = …` for photo n+1 once photo n shows). Also preload the first photo of the end-of-game carousel set. The crossfade waits for `decode()`, so there's never a half-painted image. |
| C8 | **House config without a bonus link** | The chip renders as a `<span>`, not a link. The footer leaves out "· bonus link". |
| C9 | **House without the verdict question** (48 of 153) | Share copies straight away: no sheet, then the toast and "Copied!". |
| C10 | **Unknown or missing country** in the house config | Fall back to `it`. Log a console warning once in development. |
| C11 | **House number not derivable** | The chip reads "Casa · Italia" (no "Nº"). |
| C12 | **Non-ASCII place and country names** ("España", "Spíti") | The fonts include Latin-1 and Latin Extended (`manrope-ext.woff2`). Check for missing glyphs. |

## Input and rules

| # | Case | Required behaviour |
|---|---|---|
| I1 | Letters, spaces, "€", "k", "." or "," typed or pasted | Strip them as you type, so "450k" becomes "450" and then the < €10,000 error appears on submit. "€ 1.250.000" pastes as "1,250,000". |
| I2 | Leading zeros | Strip them ("000450000" → "450,000"). |
| I3 | More than 9 digits | Cap at 9 (max €999,999,999). |
| I4 | Below €10,000 | "Enter the full price, e.g. 450,000" + shake. **No try used.** |
| I5 | The same value as an earlier guess | "You already tried €650,000" + shake. **No try used.** |
| I6 | Enter with an empty field | Nothing (the button is disabled; the form ignores it). |
| I7 | Double-tap on Guess or Enter-spam | Submitting is idempotent per value: ignore a second submit while the first is processing, and only one try is used. |
| I8 | Exactly ±10% | Use the app's existing comparison (inclusive or exclusive as it is today). **Don't change it.** |
| I9 | Exactly 30% off | The existing logic decides single vs double arrow. Don't change it. |
| I10 | Exact price on try 1 | Exact flow; the other 5 circles become "unused" after 2s. |
| I11 | Win on try 6 | The win flow, with no unused circles. The last-try breathing stops at once (the state changes to `right`). |
| I12 | Mobile keyboard | After a wrong guess the input keeps focus (the keyboard stays). The photo, circles and field all fit above a typical keyboard on a 390×844 phone, because they're the top of the page. At game end, blur the input to close the keyboard before the card rises. |
| I13 | iOS zoom-on-focus | The field font size is 20px (≥16px), so iOS doesn't zoom. |

## Persistence, dates and URLs

| # | Case | Required behaviour |
|---|---|---|
| P1 | **Reload mid-game** | Restore with no animation (`no-anim` for 2 frames). Circles, the photo for the current try, the hint, and the clue dots match the saved state. The Clues panel is closed. |
| P2 | **Reload a finished game** | The result card shows at once with the final price (no count-up), **no confetti or rain**, all shutters open, unused circles already faded, and carousel autoplay running. Fixes "celebrations replay on reload". Save a flag such as `celebrated: true` in the existing per-house save (additive), or use a separate key `gmc-celebrated-<dayKey>`. |
| P3 | **Old saves from before the deploy** | Must load. Every new field is optional, with defaults. |
| P4 | **Theme preference** | Key `gmc-theme` = `dark` or `light`. Missing or invalid → dark. `localStorage` can throw (private mode, Safari ITP), so wrap it in try/catch and fall back to dark. |
| P5 | **No flash of the wrong theme** | The inline script in `<head>` sets `data-theme` before the CSS loads. With SSR or prerendering, render `data-theme="dark"` by default. |
| P6 | **Past-day link** (`?day=31_10_26`) | Banner, a separate save, the countdown hidden and the date shown instead. Share links still pin their day. "Today's casa →" drops the `day` param. Today, future or invalid dates quietly open today's house (unchanged). |
| P7 | **Reset passes while the tab is open** (10:00 Europe/Kyiv) | The existing auto-reload stays. If a sheet or the zoom is open, reload anyway (unchanged behaviour). |
| P8 | **Tab hidden for hours** | On `visibilitychange`, recompute the countdown immediately; don't rely on interval ticks. |
| P9 | **No house today** | "No casa today" screen; no game state is read or written. |
| P10 | **Seasonal theme active on a past-day link** | Use the season of the **house's date** (the same rule as today), not of the current date. |

## Sharing

| # | Case | Required behaviour |
|---|---|---|
| S1 | Clipboard write succeeds | Toast + "Copied!" for 2.5s. |
| S2 | Clipboard API missing, insecure context or permission denied | Open the **copy-fallback sheet** with the textarea pre-selected. No toast. |
| S3 | Share pressed again within 2.5s | Copy again and restart the 2.5s timer and the toast. Don't stack toasts. |
| S4 | Verdict already saved | Share copies straight away, and the verdict line is included. |
| S5 | The verdict sheet dismissed (scrim, Escape, drag, Skip) | Copy without the verdict (as today); the sheet comes back on the next Share until the player votes. |
| S6 | The share text | Must never contain "€" or digits of the price. Assert this in a unit test if the repo has tests. |

## Layout and devices

| # | Case | Required behaviour |
|---|---|---|
| L1 | **320px-wide phones** | Circles at 40px; title 24px; the countdown label hidden; verdict tiles still on one line. See `screenshots/50-small-phone-320-last-try.jpg`. |
| L2 | **Tablet or desktop** | Single 440px column, centred; full-bleed awning, past-day banner and anchor bar; sheets max 440px, centred; zoom stage max 900px. |
| L3 | **Landscape phone** | Same column; the zoom stage is limited to `max-height: 78vh`; sheets scroll internally if taller than the viewport (`max-height: 90vh; overflow-y: auto`). |
| L4 | **iPhone safe areas** | `viewport-fit=cover`. The anchor ad, sheets and toast use `env(safe-area-inset-*)`. |
| L5 | **Ads off / no fill** | No empty boxes in production, and no bottom padding without an anchor ad (spec/03 §10). |
| L6 | **Ad scripts injecting high z-index** | Sheets, zoom and toast must stay above the anchor ad (1100 < 1200+). |
| L7 | **Font not loaded yet** | System fallback with similar metrics; no layout jump bigger than a few px (`font-display: swap`, preload). |
| L8 | **Browser zoom 200% / large text** | Nothing clips: the circle labels can wrap below; the clue pill clamps to 2 lines and may overlap the photo more; sheets scroll. |
| L9 | **Long country chip** ("Maison Nº 153 · France") | Fits at 320px alongside the clock-only countdown. If it ever overflows, the chip truncates with an ellipsis before the countdown wraps. |

## Map

| # | Case | Required behaviour |
|---|---|---|
| M1 | Mouse wheel over the map while scrolling the page | The page scrolls. The wheel zooms only after the map was clicked or focused (fixes brief §9). |
| M2 | Theme or country switch | Tiles re-filter instantly (CSS variable) and the pin recolours: rebuild the `divIcon` HTML or use `currentColor` from a CSS variable. |
| M3 | Overlays | All overlays sit above Leaflet panes and controls. |
| M4 | Tile load failure | The `--raised` background shows; the attribution stays. |

## Motion and accessibility

| # | Case | Required behaviour |
|---|---|---|
| A1 | `prefers-reduced-motion` | Everything in spec/04 §10. |
| A2 | Screen reader on a wrong guess | The helper line or a visually-hidden live region announces e.g. "€300,000 is far too low. Try 2 of 6." |
| A3 | Screen reader at game end | The result card region announces the title, price and summary line. |
| A4 | Carousel autoplay with a screen reader | Don't announce every autoplay step (no `aria-live` on the clue pill while autoplay runs). |
| A5 | Keyboard only | Every flow can be completed with Tab, Enter, Space, Escape and the arrow keys (in the zoom). Focus is visible everywhere and trapped in dialogs. |
| A6 | `forced-colors` (Windows High Contrast) | Circles and tiles keep visible borders (`forced-color-adjust: auto`); the shutter pattern can disappear but the "Clue 5" pill text stays readable. |
