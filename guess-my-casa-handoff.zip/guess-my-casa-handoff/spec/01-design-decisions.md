# 01 · Design decisions

## 1. Goals (from the owner)

- Keep what works: **portrait, single column, mobile-first**, and "just enough" information per screen.
- Make it **its own European game**, not a reskin of guessthe.house. It must work for houses in **Italy, Portugal, Spain, France and Greece**.
- **Simple and elegant**, with good mobile ergonomics and **room for banner ads**.
- **Dark mode by default, plus light mode.**
- **A new hint must not push the rest of the page down.**
- Keep the cheeky tone and the motion.

## 2. The approved direction

The owner reviewed five directions and picked a combination of two:

- **Look from "Trattoria" (cozy Mediterranean):**
  - a striped café awning with a scalloped edge across the top
  - warm cream in light mode
  - Fraunces serif headings
  - accent colours that follow the house's country
- **Layout from "Notte" (evening):**
  - a deep night-blue dark mode
  - round try circles with the **direction arrow inside the circle and the guessed value underneath** (kept separate)
  - a **Guess button inside the price field**
  - a glowing "now" circle
- **The owner's own changes on top:**
  - The current clue is a **clue pill** above the photo: it overlaps the photo's top edge and **hangs past its left edge** (the photo shifts slightly right). It uses the same surface colour as the Clues drawer and is rounded on both ends, with a **drawn magnifying glass** on the left. The same magnifier marks the Clues bar and every unlocked clue tile.
  - All clues live in a **collapsible "Clues" panel**. Locked clues are hidden **behind closed window shutters** that swing open when the clue unlocks.
  - The name changes to **"Guess My Casa"**.

## 3. Old → new component map

| Today (brief §3) | New | Notes |
|---|---|---|
| Title "Guess The House" + Italy-map icon (links to the YouTube bonus) | Title "Guess My Casa", plus a **flag chip** in the meta row ("Casa Nº 153 · Italia"). The chip is the bonus link | The disguise country drives the flag, name and word for "house" |
| No help | **"?" button**, which opens the How-to-play sheet | Fixes "rules aren't explained" |
| No theme switch | **Sun/moon button** | Dark default, light remembered |
| Photo + `n / 6` badge + zoom button | **Clue pill** above the photo (overlapping its top edge, hanging off its left edge) + photo (4:3, radius 20) + zoom button with an **expand** icon | The circles already show which photo you're on, so the badge is gone. The zoom icon is no longer a magnifier, because the magnifier now means "clue" |
| Hints list (below the photo on mobile, right-hand column on desktop) | **Removed.** The current clue is in the clue pill; all clues are in the Clues panel | The input no longer drifts down |
| 6 numbered try buttons, 24×24 | **6 try circles, 46px** (min 40px), with the arrow/check inside and the value below | Also the guess history |
| "New Game in 21h 59m 58s" under the tries | Countdown in the meta row ("New casa in 21:59:58"); also on the result card | |
| Input + full-width Submit, both 32px tall | One **60px pill** with the € prefix and a 48px **Guess** button inside | Bigger targets, stays in one place |
| List of past guesses (disappears at game end) | **Removed.** The circles hold the history, which stays visible after the game | Fixes brief §9 |
| Map (240px) | Map (180px, radius 20); dark-mode tile filter; accent-coloured pin; wheel zoom only after a click | |
| Result: banner + text + link + Share | **Result card** that replaces the input: title, "ASKING PRICE", price (counts up), summary line, full-width Share, "View listing ↗", next-casa countdown | |
| End-of-game carousel (arrows on photo, auto-advance) | Same behaviour, restyled arrows; the clue pill follows the photo | |
| Photo zoom (black backdrop, no arrows during play) | Same, plus a FLIP open/close animation, the clue pill above the image, dots and a caption; arrows, swipe and ←/→ after the game | |
| Verdict popup (centred modal with Tassos and 3 emoji cards) | **Bottom sheet**: thumbnail + price + place, the question, 3 equal tiles with line icons (Steal / Fair / Rip-off), "Skip and copy result" | Fixes "Rip-off" wrapping; no Tassos |
| Share button shows "Copied" for 2.5s | The button turns green ("✓ Copied!") **and** a toast drops in at the top. If the clipboard fails, a **copy-fallback sheet** opens | Fixes "failed copy gets no feedback" |
| Past-day amber banner (container width) | **Edge-to-edge sticky banner** in the accent colour; the meta row shows the date instead of the countdown | Fixes the desktop width bug |
| "No puzzle today" text | **"No casa today"** card: closed shutters, a short line, a big countdown, "Play yesterday's casa" | |
| Halloween theme | Same idea through `data-season="halloween"` token overrides, with its existing effects layered on top | Also themes the sheets (brief §9 says the popup wasn't themed) |
| 👎 loss rain, confetti on win | Kept, using SVG thumbs-down and flag-coloured confetti; **played once per game**, not on reload | |
| No ads | **300×250** slot under the map, **320×50** sticky anchor at the bottom | Space is reserved, so nothing shifts |

## 4. What deliberately does not change

- The rules, tries, thresholds, arrows and exact-price logic.
- The daily schedule, the 10:00 Europe/Kyiv reset, auto-reload and the countdown logic.
- The `?day=` URL format and its separate saves.
- Storage keys and format (only additive changes).
- The share text format, apart from the name (spec/08).
- Which houses ask the verdict question; the verdict is saved, and later shares skip the popup.
- Analytics events (keep every existing call; add new ones only if the existing helper makes it trivial: `theme_toggle`, `help_open`, `clues_toggle`, `zoom_open`).
- The intentional jokes.

## 5. Assumptions about the audience

Mostly mobile players opening a shared link from a chat app, playing for 1–3 minutes, often one-handed. Desktop is secondary: the same column, centred.
